package com.theunkwn.simulator;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.widget.*;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
public class MainActivity extends Activity {
 private byte[] pending;
 @Override public void onCreate(Bundle b) { super.onCreate(b); LinearLayout l=new LinearLayout(this); l.setOrientation(1); l.setPadding(24,48,24,24); TextView title=new TextView(this); title.setText("TheUnkwn Threat Simulator\nHarmless test data only. No network access.\nChoose Downloads when saving. Delete test files using Files after testing."); l.addView(title); setContentView(l);
 add(l,"EICAR signature test","eicar-test.txt", "X5O!P%@AP[4"+(char)92+"PZX54(P^)7CC)7}"+(char)36+"EICAR-STANDARD-ANTIVIRUS-TEST-FILE!"+(char)36+"H+H*");
 add(l,"Clean control file","clean-control.txt","Harmless control file. No threat indicators.");
 for(String type:new String[]{"Trojan","Spyware","Polymorphic","Certificate","Network"}) add(l,type+" synthetic fixture", "simulation-"+type+".txt", "SIMULATION ONLY: "+type+". Inert fixture; no malicious behavior. Not a malware detection test.");
 }
 private void add(LinearLayout l,String label,String name,String data){ Button b=new Button(this); b.setText(label); l.addView(b); b.setOnClickListener(v->{pending=data.getBytes(StandardCharsets.US_ASCII); Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("text/plain").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,name); startActivityForResult(i,1);}); }
 @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d); if(r!=1||c!=RESULT_OK||d==null||pending==null)return; try(OutputStream o=getContentResolver().openOutputStream(d.getData(),"wt")){if(o==null)throw new Exception();o.write(pending);Toast.makeText(this,"Test data saved",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Save failed",Toast.LENGTH_LONG).show();}finally{pending=null;}}
}
