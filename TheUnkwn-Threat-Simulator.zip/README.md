# Threat Simulator
Separate permission-free Android app. Extract ZIP into a separate GitHub repo, run Build Threat Simulator. Install debug APK, open, save EICAR and clean control in Downloads, scan both. Installation itself tests install notifications. Other fixtures are inert text labels only and do not exercise actual Trojan/spyware/network detection. Delete through Files. No network permission, no malware, no background service. EICAR reference: https://www.eicar.org/download-anti-malware-testfile/. Build/device testing not performed.


Combined repository build: place TheUnkwn.zip and TheUnkwn-Threat-Simulator.zip at repository root and install the supplied combined android.yml in .github/workflows/. The simulator builds separately as TheUnkwn-Threat-Simulator.apk.
