import sys,json,pathlib
import pandas as pd,numpy as np
from sklearn.model_selection import GroupShuffleSplit
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix,accuracy_score,roc_auc_score
f=['ReadSms','ReceiveSms','Internet','AccessCoarseLocation','AccessFineLocation','SendSms','Vibrate','ChangeWifiState']
d=pd.read_csv(sys.argv[1]).dropna(); d=d[d.Sha256.str.fullmatch('[a-fA-F0-9]{64}') & d.Label.isin([0,1])].copy();d.Sha256=d.Sha256.str.lower();d=d[~d.Sha256.isin(d.groupby('Sha256').Label.nunique().loc[lambda s:s>1].index)].drop_duplicates('Sha256');g=pd.util.hash_pandas_object(d.drop(columns=['Sha256','Label']),index=False);x=(d[f].to_numpy()>0).astype(int);y=d.Label.to_numpy();a,b=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=42).split(x,y,g));m=LogisticRegression(max_iter=300,class_weight='balanced').fit(x[a],y[a]);s=m.predict_proba(x[b])[:,1];r={'features':f,'weights':m.coef_[0].tolist(),'bias':float(m.intercept_[0]),'train':len(a),'test':len(b),'accuracy':float(accuracy_score(y[b],s>=.5)),'auc':float(roc_auc_score(y[b],s)),'thresholds':{},'limitation':'Nonzero research counts are a proxy for manifest permission presence; equivalence not verified. Advisory only; not calibrated or temporally validated.'};
for t in [.5,.8,.9]:
 tn,fp,fn,tp=confusion_matrix(y[b],s>=t,labels=[0,1]).ravel();r['thresholds'][str(t)]={'tn':int(tn),'fp':int(fp),'fn':int(fn),'tp':int(tp),'recall':float(tp/(tp+fn)),'fpr':float(fp/(fp+tn))}
pathlib.Path(sys.argv[2]).write_text(json.dumps(r,indent=2));print(json.dumps(r))
