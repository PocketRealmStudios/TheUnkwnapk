"""Train only on reviewed, pre-extracted Android feature records; never execute samples."""
import argparse, csv, json, math, pathlib
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, confusion_matrix
FEATURES=['entropy','zip_header','log_prefix_length','zero_fraction','printable_fraction']
p=argparse.ArgumentParser(); p.add_argument('csv'); p.add_argument('--out',default='training-output'); a=p.parse_args()
rows=list(csv.DictReader(open(a.csv,encoding='utf-8')))
# Require disjoint provenance groups and explicit chronological split assigned by dataset curator.
train=[r for r in rows if r['split']=='train']; test=[r for r in rows if r['split']=='test']
assert len(train)>=100 and len(test)>=100, 'Need at least 100 reviewed records per split'
assert not ({r['group'] for r in train}&{r['group'] for r in test}), 'Group leakage'
assert all(r['group'].strip() for r in rows)
def data(rs):
 x=np.array([[float(r[k]) for k in FEATURES] for r in rs]); y=np.array([int(r['label']) for r in rs]); assert np.isfinite(x).all() and set(y)=={0,1}; return x,y
x,y=data(train); xt,yt=data(test)
m=LogisticRegression(max_iter=2000,class_weight='balanced').fit(x,y)
s=m.predict_proba(xt)[:,1]; tn,fp,fn,tp=confusion_matrix(yt,s>=.9,labels=[0,1]).ravel()
metrics={'auc':float(roc_auc_score(yt,s)), 'false_positive_rate':float(fp/(fp+tn)), 'recall':float(tp/(tp+fn)), 'train_count':len(train),'test_count':len(test)}
out=pathlib.Path(a.out); out.mkdir(parents=True,exist_ok=True); (out/'metrics.json').write_text(json.dumps(metrics,indent=2)); print(metrics)
# Conservative prototype release gate, not certification.
if metrics['auc']<.8 or metrics['false_positive_rate']>.02 or metrics['recall']<.5: raise SystemExit('Model rejected; review dataset/features')
(out/'ninjuku_model.json').write_text(json.dumps({'schema':1,'features':FEATURES,'weights':m.coef_[0].tolist(),'bias':float(m.intercept_[0]),'threshold':.9},indent=2))
