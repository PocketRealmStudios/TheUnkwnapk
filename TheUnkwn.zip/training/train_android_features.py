"""Research-only classifier for reviewed, pre-extracted Android feature tables."""
import argparse, json, pathlib
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, confusion_matrix
p=argparse.ArgumentParser(); p.add_argument('csv'); p.add_argument('--out',default='training-output'); a=p.parse_args()
d=pd.read_csv(a.csv); required={'label','group','split'}
if not required.issubset(d): raise ValueError('Missing label/group/split')
f=sorted(c for c in d if c.startswith(('permission_','api_','feature_')))
if not f: raise ValueError('No reviewed feature columns')
if d[list(required)].isna().any().any() or not set(d.split)=={'train','test'}: raise ValueError('Invalid metadata')
x=d[f].apply(pd.to_numeric); import numpy as np
if not np.isfinite(x).all().all() or not x.isin([0,1]).all().all(): raise ValueError('Expected binary features')
t=d.split=='train'; v=~t
if set(d.loc[t,'group']) & set(d.loc[v,'group']): raise ValueError('Group leakage')
for mask in (t,v):
 if mask.sum()<100 or set(d.loc[mask,'label'])!={0,1}: raise ValueError('Need both classes and >=100 rows per split')
m=LogisticRegression(max_iter=2000,class_weight='balanced').fit(x[t],d.label[t]); s=m.predict_proba(x[v])[:,1]; tn,fp,fn,tp=confusion_matrix(d.label[v],s>=.9,labels=[0,1]).ravel()
o=pathlib.Path(a.out); o.mkdir(parents=True,exist_ok=True)
metrics={'auc':float(roc_auc_score(d.label[v],s)),'false_positive_rate':float(fp/(fp+tn)),'recall':float(tp/(tp+fn)),'train_count':int(t.sum()),'test_count':int(v.sum())}
(o/'real_feature_metrics.json').write_text(json.dumps(metrics,indent=2)); (o/'research_candidate_NOT_FOR_DEPLOYMENT.json').write_text(json.dumps({'features':f,'weights':m.coef_[0].tolist(),'bias':float(m.intercept_[0]),'threshold':.9},indent=2)); print(metrics)
