"""Synthetic feature pipeline test only; labels denote artificial patterns, NOT malware."""
import csv, math, random, pathlib
from collections import Counter
rng=random.Random(1301)
out=pathlib.Path(__file__).with_name('synthetic.csv')
fields=['entropy','zip_header','log_prefix_length','zero_fraction','printable_fraction','label','group','split']
with out.open('w',newline='') as f:
 w=csv.writer(f); w.writerow(fields)
 for split in ('train','test'):
  for i in range(400):
   label=i%2; n=rng.randint(1024,8192)
   alphabet=range(256) if label else range(32,127)
   b=bytes(rng.choices(alphabet,k=n)); c=Counter(b)
   w.writerow([-sum((v/n)*math.log2(v/n) for v in c.values()),int(b[:2]==b'PK'),math.log1p(n),c[0]/n,sum(c[j] for j in range(32,127))/n,label,f'{split}-{i}',split])
