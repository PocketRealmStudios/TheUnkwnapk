import pandas as pd, numpy as np, json, pathlib, sys
from sklearn.model_selection import GroupShuffleSplit
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, confusion_matrix, accuracy_score
from sklearn.preprocessing import StandardScaler
p=pathlib.Path(sys.argv[2]); p.mkdir(parents=True,exist_ok=True)
d=pd.read_csv(sys.argv[1]); counts=d.Label.value_counts().to_dict(); d=d.dropna(); d=d[d.Sha256.str.fullmatch('[a-fA-F0-9]{64}') & d.Label.isin([0,1])]; d['Sha256']=d.Sha256.str.lower(); d=d[~d.Sha256.isin(d.groupby('Sha256').Label.nunique().loc[lambda s:s>1].index)].drop_duplicates('Sha256'); f=[c for c in d if c not in ['Sha256','Label']]; x=d[f].to_numpy(dtype=float); assert np.isfinite(x).all() and (x>=0).all(); y=d.Label.to_numpy(); groups=pd.util.hash_pandas_object(d[f],index=False).to_numpy(); a,b=next(GroupShuffleSplit(n_splits=1,test_size=.2,random_state=42).split(x,y,groups)); assert not set(groups[a])&set(groups[b]); results={};
for name,features in [('all',f),('permissions',['ReadSms','ReceiveSms','Internet','AccessCoarseLocation','AccessFineLocation','SendSms','Vibrate','ChangeWifiState'])]:
 z=np.log1p(d[features].to_numpy(dtype=float)); scaler=StandardScaler().fit(z[a]); m=LogisticRegression(max_iter=300,class_weight='balanced').fit(scaler.transform(z[a]),y[a]); s=m.predict_proba(scaler.transform(z[b]))[:,1]; metrics={'auc':float(roc_auc_score(y[b],s)),'accuracy_at_0.5':float(accuracy_score(y[b],s>=.5))};
 for threshold in [.5,.9]:
  tn,fp,fn,tp=confusion_matrix(y[b],s>=threshold,labels=[0,1]).ravel(); metrics[str(threshold)]={'tn':int(tn),'fp':int(fp),'fn':int(fn),'tp':int(tp),'recall':float(tp/(tp+fn)),'fpr':float(fp/(fp+tn))}
 results[name]=metrics; (p/(name+'_research_model.json')).write_text(json.dumps({'features':features,'transform':'log1p then standardize','mean':scaler.mean_.tolist(),'scale':scaler.scale_.tolist(),'weights':m.coef_[0].tolist(),'bias':float(m.intercept_[0]),'deployment':'research only'},indent=2))
report={'source_counts':{str(k):int(v) for k,v in counts.items()},'usable':len(d),'train':len(a),'test':len(b),'features':len(f),'split':'grouped by identical full feature vectors, unique SHA256; not temporal or family split','results':results}; (p/'metrics.json').write_text(json.dumps(report,indent=2)); print(json.dumps(report,indent=2))
