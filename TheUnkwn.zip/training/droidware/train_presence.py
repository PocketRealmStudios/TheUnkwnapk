import pandas as pd, numpy as np, json, sys
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, accuracy_score
from sklearn.model_selection import train_test_split
from pathlib import Path
features=['ReadSms','ReceiveSms','Internet','AccessCoarseLocation','AccessFineLocation','SendSms','Vibrate','ChangeWifiState']
d=pd.read_csv(sys.argv[1],usecols=['Sha256','Label']+features).dropna(); d=d[d.Label.isin([0,1]) & (d[features]>=0).all(axis=1)]; d=d[~d.Sha256.duplicated(keep=False)]
x=(d[features].to_numpy()>0).astype(int); y=d.Label.to_numpy(); a,b=train_test_split(np.arange(len(y)),test_size=.2,random_state=42,stratify=y)
m=LogisticRegression(max_iter=500).fit(x[a],y[a]); p=m.predict_proba(x[b])[:,1]; result={'features':features,'weights':m.coef_[0].tolist(),'bias':float(m.intercept_[0]),'train':len(a),'test':len(b),'accuracy':accuracy_score(y[b],p>=.5),'threshold':.9,'confusion_at_0.9':confusion_matrix(y[b],p>=.9).tolist(),'limitations':'SHA256-disjoint random split; identical permission patterns may overlap; dataset nonzero values are a proxy for permission presence, not verified manifest parity; research only.'}; Path(sys.argv[2]).write_text(json.dumps(result,indent=2)); print(result)
