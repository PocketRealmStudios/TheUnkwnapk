#!/usr/bin/env bash
# Uses the official Gradle Wrapper. Gradle 8.9 is downloaded on first use
# and verified against distributionSha256Sum in gradle-wrapper.properties.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$ROOT/gradlew" "$@"
