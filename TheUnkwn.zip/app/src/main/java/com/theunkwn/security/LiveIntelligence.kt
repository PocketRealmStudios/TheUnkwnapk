package com.theunkwn.security

import android.content.Context
import java.net.URL
import javax.net.ssl.HttpsURLConnection
import org.json.JSONObject

/** Downloads public intelligence only; never uploads device data. */
object LiveIntelligence {
    private val sources = linkedMapOf(
        "CISA KEV" to "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json",
        "MITRE Mobile ATT&CK" to "https://raw.githubusercontent.com/mitre-attack/attack-stix-data/master/mobile-attack/mobile-attack.json",
        "ThreatFox" to "https://threatfox.abuse.ch/export/json/recent/",
        "URLhaus" to "https://urlhaus.abuse.ch/downloads/json_recent/"
    )
    fun refresh(context: Context): String = sources.map { (name, url) ->
        try {
            val c = URL(url).openConnection() as HttpsURLConnection
            val data = try {
                c.connectTimeout = 10000; c.readTimeout = 15000; c.instanceFollowRedirects = false
                check(c.responseCode == 200) { "HTTP ${c.responseCode}" }
                c.inputStream.use { input ->
                    val out = java.io.ByteArrayOutputStream(); val buf = ByteArray(8192)
                    while (true) { val n = input.read(buf); if (n < 0) break; check(out.size()+n <= 24*1024*1024); out.write(buf,0,n) }
                    out.toString("UTF-8")
                }
            } finally { c.disconnect() }
            val json = JSONObject(data); check(json.length() > 0)
            val prefs = context.getSharedPreferences("live_intelligence", Context.MODE_PRIVATE)
            val hashes = Regex("(?i)\\b[0-9a-f]{64}\\b").findAll(data).map { it.value.lowercase() }.take(50000).toSet()
            // Only explicit ThreatFox SHA-256 IOC records are eligible for matching.
            val exact = mutableSetOf<String>()
            if (name == "ThreatFox") for (key in json.keys()) {
                val arr = json.optJSONArray(key) ?: continue
                for (i in 0 until arr.length()) {
                    val r = arr.optJSONObject(i) ?: continue
                    val value = r.optString("ioc_value").lowercase()
                    if (r.optString("ioc_type") == "sha256_hash" && value in hashes) exact.add(value)
                }
            }
            prefs.edit().putLong("time:$name", System.currentTimeMillis()).putStringSet("hash:$name", exact).apply()
            "$name: downloaded (${json.length()} top-level fields; ${exact.size} exact hash indicators)"
        } catch (e: Exception) { "$name: unavailable; previous cache retained (${e.javaClass.simpleName})" }
    }.joinToString("\n")
    fun matches(context: Context, hash: String): Boolean = hash.isNotBlank() && context.getSharedPreferences("live_intelligence", Context.MODE_PRIVATE).let { p ->
        System.currentTimeMillis() - p.getLong("time:ThreatFox", 0) in 0..604800000L && hash in p.getStringSet("hash:ThreatFox", emptySet()).orEmpty()
    }
}
