package com.theunkwn.security

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream

/** User-approved, per-app local VPN sink. No packets are forwarded or recorded. */
class ThreatFreezeService : VpnService() {
    @Volatile private var tunnel: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel("freeze", "Threat Freeze", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, ThreatFreezeService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        startForeground(190, Notification.Builder(this, "freeze").setSmallIcon(android.R.drawable.ic_lock_lock).setContentTitle("Threat Freeze starting").setContentIntent(open).setOngoing(true).addAction(Notification.Action.Builder(null, "Unfreeze", stop).build()).build())
        closeTunnel()
        try {
            val packages = getSharedPreferences("threat_freeze", MODE_PRIVATE).getStringSet("packages", emptySet()).orEmpty()
            val builder = Builder().setSession("TheUnkwn Threat Freeze").addAddress("10.111.0.1", 32).addRoute("0.0.0.0", 0).addAddress("fd00:111::1", 128).addRoute("::", 0).addDnsServer("10.111.0.2").setBlocking(true)
            var count = 0
            for (pkg in packages) {
                if (pkg == packageName) continue
                val info = try { packageManager.getApplicationInfo(pkg, 0) } catch (_: android.content.pm.PackageManager.NameNotFoundException) { continue }
                if ((info.flags and (android.content.pm.ApplicationInfo.FLAG_SYSTEM or android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0) continue
                builder.addAllowedApplication(pkg); count++
            }
            check(count > 0) { "No eligible apps" }
            val fd = builder.establish() ?: error("VPN permission unavailable")
            tunnel = fd
            worker = Thread {
                try { FileInputStream(fd.fileDescriptor).use { input -> val buffer = ByteArray(32767); while (!Thread.currentThread().isInterrupted && input.read(buffer) >= 0) { /* discard */ } } } catch (_: Exception) {} finally { if (tunnel === fd) stopSelf() }
            }.apply { start() }
            manager.notify(190, Notification.Builder(this, "freeze").setSmallIcon(android.R.drawable.ic_lock_lock).setContentTitle("Threat Freeze active").setContentText("Network isolation: $count selected app(s)").setContentIntent(open).setOngoing(true).addAction(Notification.Action.Builder(null, "Unfreeze", stop).build()).build())
        } catch (e: Exception) {
            manager.notify(191, Notification.Builder(this, "freeze").setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("Threat Freeze failed").setContentText("Network isolation is not active").build())
            stopSelf()
        }
        return START_NOT_STICKY
    }
    private fun closeTunnel() { val old = tunnel; tunnel = null; worker?.interrupt(); worker = null; try { old?.close() } catch (_: Exception) {} }
    override fun onRevoke() { stopSelf(); super.onRevoke() }
    override fun onDestroy() { closeTunnel(); super.onDestroy() }
}
