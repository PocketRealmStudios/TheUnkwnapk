package com.theunkwn.security
object EicarTest {
    private val signature = ("X5O!P%@AP[4" + 92.toChar() + "PZX54(P^)7CC)7}" + 36.toChar() + "EICAR-STANDARD-ANTIVIRUS-TEST-FILE!" + 36.toChar() + "H+H*").toByteArray(Charsets.US_ASCII)
    fun matches(bytes: ByteArray): Boolean = bytes.size in 68..128 && bytes.copyOfRange(0,68).contentEquals(signature) && bytes.drop(68).all { it.toInt() in listOf(9,10,13,26,32) }
}
