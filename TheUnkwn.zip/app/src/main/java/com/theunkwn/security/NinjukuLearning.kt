package com.theunkwn.security
import android.content.Context
import kotlin.math.*
import org.json.JSONObject
class NinjukuLearning(context: Context) {
 private val model = runCatching { context.assets.open("ninjuku_model.json").bufferedReader().use { JSONObject(it.readText()) } }.getOrNull()
 private val p = context.getSharedPreferences("ninjuku_model", Context.MODE_PRIVATE)
 @Synchronized fun inspect(bytes: ByteArray, findings: MutableList<String>) {
  if (bytes.isEmpty()) return
  val counts = IntArray(256); val n = minOf(bytes.size, 65536)
  for (i in 0 until n) counts[bytes[i].toInt() and 255]++
  val entropy = counts.filter { it > 0 }.sumOf { val q = it.toDouble()/n; -q*ln(q)/ln(2.0) }
  model?.let { m ->
   runCatching {
    require(m.getInt("schema") == 1)
    val names = listOf("entropy", "zip_header", "log_prefix_length", "zero_fraction", "printable_fraction")
    val declared = m.getJSONArray("features")
    require(declared.length() == names.size && names.indices.all { declared.getString(it) == names[it] })
    val features = doubleArrayOf(entropy, if (n >= 2 && bytes[0] == 80.toByte() && bytes[1] == 75.toByte()) 1.0 else 0.0, ln(1.0+n), counts[0].toDouble()/n, (32..126).sumOf { counts[it] }.toDouble()/n)
    val weights = m.getJSONArray("weights")
    require(weights.length() == features.size)
    val score = 1.0/(1.0+exp(-(m.getDouble("bias") + features.indices.sumOf { features[it]*weights.getDouble(it) })))
    if (score >= m.getDouble("threshold")) findings.add("NINJUKU MODEL: elevated statistical risk; review only")
   }
  }
  val bucket = if (bytes.size >= 2 && bytes[0]==80.toByte() && bytes[1]==75.toByte()) "zip" else "other"
  val count = p.getInt(bucket+"n",0); val mean = p.getFloat(bucket+"m",0f).toDouble(); val variance = p.getFloat(bucket+"v",1f).toDouble()
  val anomaly = count >= 30 && abs(entropy-mean)>max(1.5,3*sqrt(variance))
  if (anomaly) findings.add("NINJUKU: unusual byte distribution; review only")

 }
 fun status() = "${if (model == null) "No trained model installed." else "Experimental model asset loaded."} Experimental entropy baseline (automatic unverified training disabled). Samples: ${p.getInt("zipn",0)+p.getInt("othern",0)}. Unusual patterns are review indicators, not malware verdicts. No automatic quarantine."
 @Synchronized fun reset() { p.edit().clear().apply() }
}
