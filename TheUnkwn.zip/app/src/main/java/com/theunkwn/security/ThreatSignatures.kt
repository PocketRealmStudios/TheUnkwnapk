package com.theunkwn.security

import android.content.Context
import java.io.InputStream
import java.io.File
import java.security.MessageDigest
import java.util.Locale

/** Explicit user-imported hash list. No files or hashes are transmitted. */
class ThreatSignatures(context: Context) {
    private val file = File(context.filesDir, "trusted_sha256.txt")
    @Volatile private var hashes: Set<String> = file.takeIf { it.exists() }?.readLines()?.toSet() ?: emptySet()
    @Synchronized fun importHashes(input: InputStream): Int {
        val next = mutableSetOf<String>()
        input.bufferedReader().use { reader ->
            var lines = 0
            while (true) {
                val line = reader.readLine() ?: break
                require(++lines <= 250000 && line.length <= 512) { "List exceeds limits" }
                val token = line.trim().substringBefore(' ').lowercase(Locale.ROOT)
                if (token.matches(Regex("[0-9a-f]{64}"))) next.add(token)
            }
        }
        require(next.isNotEmpty()) { "No valid SHA-256 hashes" }
        val tmp = File(file.parentFile, "trusted_sha256.tmp")
        tmp.writeText(next.joinToString("\n"))
        check(tmp.renameTo(file)) { "Could not replace signature list" }
        hashes = next.toSet()
        return next.size
    }
    fun check(open: () -> InputStream): String? {
        val snapshot = hashes
        if (snapshot.isEmpty()) return null
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            open().use { input ->
                val buffer = ByteArray(65536)
                while (true) { val n = input.read(buffer); if (n < 0) break; digest.update(buffer, 0, n) }
            }
            val hash = digest.digest().joinToString("") { "%02x".format(it.toInt() and 255) }
            if (hash in snapshot) "IMPORTED SHA-256 MATCH: $hash (verify source and review)" else null
        } catch (_: Exception) { "SHA-256 SCAN UNAVAILABLE: file could not be read" }
    }
}
