package com.theunkwn.security

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.app.admin.DevicePolicyManager
import android.graphics.Typeface
import android.graphics.Color
import android.view.ViewGroup
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.ArrayDeque
import java.util.concurrent.Executors
import java.util.zip.ZipFile
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.UUID
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import org.json.JSONArray
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryPurchasesParams

class MainActivity : Activity() {
    private val threatApps = java.util.concurrent.ConcurrentHashMap<String, String>()
    private var currentPage = "Home"
    private lateinit var themeLayout: LinearLayout
    private lateinit var output: TextView
    private lateinit var scanButton: Button
    private val lines = mutableListOf<String>()
    private val executor = Executors.newSingleThreadExecutor()
    private val pickFolder = 41
    private val createReport = 42
    private val restoreFolderRequest = 44
    private val quarantineCandidates = mutableListOf<QuarantineCandidate>()
    private data class QuarantineCandidate(val name: String, val open: () -> InputStream?, val removeOriginal: () -> Boolean)
    private var pendingReport = ""
    private var waitingForAllFilesPermission = false
    private var billingClient: BillingClient? = null
    private val monthlyProductId = "theunkwn_premium_monthly"
    private val yearlyProductId = "theunkwn_premium_yearly"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLaunchScreen()
    }

    private val finishLaunch = Runnable {
        if (!isFinishing && !isDestroyed) {
            buildUi()
            initializeBilling()
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 71)
            }
        }
    }

    private fun showLaunchScreen() {
        val splash = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundResource(R.drawable.brand_backdrop)
        }
        splash.addView(ImageView(this).apply {
            setImageResource(R.drawable.home_logo)
            contentDescription = "TheUnkwn — Powered by Ninjuku AI"
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        splash.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            contentDescription = "Loading TheUnkwn"
        }, LinearLayout.LayoutParams(-1, -2))
        splash.addView(TextView(this).apply {
            text = "Loading TheUnkwn…"
            setTextColor(Color.rgb(242, 211, 143))
            gravity = android.view.Gravity.CENTER
            setPadding(0, 16, 0, 24)
        })
        setContentView(splash)
        // Allow the launch view to draw before building the main interface.
        clock.postDelayed(finishLaunch, 900L)
    }

    private val signatures by lazy { ThreatSignatures(this) }
    private val adaptive by lazy { NinjukuLearning(this) }
    private lateinit var usageLabel: TextView
    private var busy = false
    @Volatile private var scanning = false
    @Volatile private var paused = false
    @Volatile private var stopped = false
    private val scanLock = Object()
    private lateinit var scanStatus: TextView
    private lateinit var scanProgress: ProgressBar
    private lateinit var pauseButton: Button
    private lateinit var stopButton: Button
    private var checkedItems = 0L
    private var lastPaint = 0L
    private class ScanStopped : RuntimeException()
    private fun checkpoint(name: String) {
        synchronized(scanLock) {
            while (paused && !stopped) scanLock.wait()
            if (stopped) throw ScanStopped()
        }
        checkedItems++
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastPaint >= 120) {
            lastPaint = now
            val count = checkedItems
            runOnUiThread { if (scanning && !paused && !stopped) scanStatus.text = "TheUnkwn is scanning\n$name\n$count items checked" }
        }
    }
    private fun startScanDisplay() {
        stopped = false; paused = false; scanning = true; checkedItems = 0; lastPaint = 0
        scanStatus.text = "TheUnkwn is scanning"
        scanProgress.visibility = android.view.View.VISIBLE
        pauseButton.isEnabled = true; pauseButton.text = "Pause scan"; stopButton.isEnabled = true
        output.text = "Scan in progress. Technical details are available after scanning."
    }
    private fun endScanDisplay(completed: Boolean) {
        scanning = false; paused = false
        scanProgress.visibility = android.view.View.GONE
        pauseButton.isEnabled = false; stopButton.isEnabled = false
        scanStatus.text = if (stopped) "Scan stopped — partial results" else if (completed) "Scan finished — $checkedItems items checked" else "Scan could not finish"
        output.text = "Review results in Reports. Findings are not proof of malware."
    }
    private fun stopScan() { synchronized(scanLock) { stopped = true; paused = false; scanLock.notifyAll() } }
    private fun styleScanBar() {
        if (!::scanProgress.isInitialized) return
        val custom = File(filesDir, "custom_background.png")
        val bitmap = if (ThemePolicy.allowsCustom(currentPage) && custom.isFile) android.graphics.BitmapFactory.decodeFile(custom.absolutePath) else null
        val accent = if (bitmap != null) {
            val c = bitmap.getPixel(bitmap.width / 2, bitmap.height / 2)
            Color.HSVToColor(floatArrayOf(FloatArray(3).also { Color.colorToHSV(c, it) }[0], 0.65f, 0.95f))
        } else 0xFFD4AF37.toInt()
        bitmap?.recycle()
        scanProgress.indeterminateTintList = null
        val gradient = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(if (bitmap == null) 0xFFB91C24.toInt() else accent, accent))
        gradient.cornerRadius = 12f
        val track = android.graphics.drawable.GradientDrawable().apply { setColor(Color.BLACK); setStroke(2, accent); cornerRadius = 12f }
        scanProgress.background = track
        scanProgress.indeterminateDrawable = android.graphics.drawable.AnimationDrawable().apply {
            for (i in 1..8) {
                val frame = android.graphics.drawable.ClipDrawable(gradient.constantState!!.newDrawable().mutate(), android.view.Gravity.LEFT, android.graphics.drawable.ClipDrawable.HORIZONTAL)
                frame.level = i * 1250
                addFrame(frame, 120)
            }
            isOneShot = false
        }
        scanStatus.setTextColor(accent); scanStatus.setBackgroundColor(Color.BLACK)
    }
    private fun usageDay() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun used(kind: String): Int {
        val p = getSharedPreferences("daily_usage", MODE_PRIVATE)
        return if (p.getString("day", "") == usageDay()) p.getInt("scan", 0) + p.getInt("ai", 0) + p.getInt("completed", 0) else 0
    }
    private fun refreshUsage() {
        if (!::usageLabel.isInitialized) return
        usageLabel.text = if (hasPremiumEntitlement()) "Premium • unlimited local scans" else "FREE • ${(20-used("scan")).coerceAtLeast(0)} / 20 uses left\nResets at local midnight"
    }
    private fun startUse(kind: String): Boolean {
        if (busy) { Toast.makeText(this, "Another operation is running", Toast.LENGTH_SHORT).show(); return false }
        if (!hasPremiumEntitlement() && used(kind) >= 20) {
            Toast.makeText(this, "Daily limit reached. Resets at local midnight.", Toast.LENGTH_LONG).show(); return false
        }
        busy = true
        return true
    }
    private fun finishUse(kind: String, success: Boolean) {
        if (success && !hasPremiumEntitlement()) {
            val p = getSharedPreferences("daily_usage", MODE_PRIVATE)
            val n = used(kind)
            val e = p.edit()
            if (p.getString("day", "") != usageDay()) e.clear()
            e.remove("scan").remove("ai").putString("day", usageDay()).putInt("completed", n + 1).apply()
        }
        busy = false
        scanButton.isEnabled = true
        refreshUsage()
    }
    private val clock = android.os.Handler(android.os.Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refreshUsage(); clock.postDelayed(this, 1000) }
    }
    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 22, 24, 20)
            setBackgroundResource(R.drawable.brand_backdrop)
        }
        themeLayout = layout
        applyThemeBackground()
        val title = TextView(this).apply {
            text = "THEUNKWN"
            textSize = 29f
            typeface = resources.getFont(R.font.pocketrealm_cipher)
            letterSpacing = 0.12f
            setTextColor(Color.rgb(242, 211, 143))
            setShadowLayer(12f, 0f, 0f, Color.rgb(150, 20, 38))
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            setPadding(0, 2, 0, 2)
        }
        val studioMark = TextView(this).apply {
            text = "POCKETREALMSTUDIOS  /  SECURE SYSTEMS"
            textSize = 10f
            typeface = resources.getFont(R.font.pocketrealm_cipher)
            letterSpacing = 0.08f
            setTextColor(Color.rgb(218, 174, 89))
            gravity = android.view.Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, 12)
        }
        val intro = TextView(this).apply {
            text = "TheUnkwn combines a local malware signature/heuristic scan with app privacy and stalkerware-risk auditing. It checks accessible files and installed apps on this device. No scan data is uploaded. Findings are indicators for review, not a guaranteed malware verdict."
            textSize = 14f
            setPadding(0, 10, 0, 14)
        }
        val readme = TextView(this).apply {
            textSize = 13f
            setPadding(0, 4, 0, 12)
            text = "HOW THEUNKWN WORKS\n" +
                "1. App audit: inventories apps visible to Android and reviews sensitive permissions, accessibility-service declarations, enabled accessibility services, active device-admin apps, unknown installers and apps without launcher entries.\n" +
                "2. Malware engine: scans accessible files for the standard EICAR antivirus test signature, risky script patterns, suspicious APK manifest permissions and selected high-risk code indicators inside APK/Dex files. It uses local signatures and heuristics; it is not a commercial antivirus product and supports imported trusted SHA-256 lists; automatic feed updates are not configured.\n" +
                "3. Stalkerware review: ranks combinations of SMS, contacts, call-log, location, microphone, camera, accessibility and device-admin capabilities. This is a risk score, not proof of surveillance.\n" +
                "4. Exposure Trail: saves a private on-device baseline of sensitive app capabilities and highlights new permission/special-access indicators on later scans.\n" +
                "5. Quarantine: after an explicit confirmation, supported EICAR/suspicious-script files are copied to private app storage, verified, then removed from the original location. Restore copies them back to a folder you choose.\n" +
                "6. File audit: checks accessible shared folders for hidden or unnamed files, APK/OBB packages, executable-code types and unusual extensions. Scanning itself is read-only.\n\n" +
                "ANDROID 10 (API 29): Android 10 uses scoped storage. Tap Choose storage folder and select the shared-storage area you want checked. TheUnkwn can scan only that selected folder and descendants Android makes available; protected app-private folders, private messages, email databases and system areas are not readable by an ordinary app. Repeat with other folders if needed.\n\n" +
                "ANDROID 11+: grant the special All files access permission in Settings for a broader shared-storage scan. Android still protects other apps’ private data. App inventory visibility depends on Android version and device policy.\n\n" +
                "PRIVACY LIMIT: Android does not let this scanner inspect the contents of other apps’ SMS, email or chat stores. It checks app permission requests and visible configuration indicators instead. A suspicious permission does not prove spying; legitimate apps may need these permissions."
        }
        scanButton = Button(this).apply {
            text = "SCAN ACCESSIBLE FILES & APPS"
            setOnClickListener { beginFullScan() }
        }
        val folder = Button(this).apply {
            text = "Choose storage folder (Android 10 / fallback)"
            setOnClickListener { chooseFolder() }
        }
        val quarantine = Button(this).apply {
            text = "Quarantine flagged files"
            setOnClickListener { confirmQuarantine() }
        }
        val restore = Button(this).apply {
            text = "Restore quarantined files"
            setOnClickListener { chooseRestoreFolder() }
        }
        val watchdog = Switch(this).apply {
            text = "Security Watchdog: monitor new app installs"
            isChecked = getSharedPreferences("security_watchdog", MODE_PRIVATE).getBoolean("enabled", true)
            setOnCheckedChangeListener { _, enabled ->
                getSharedPreferences("security_watchdog", MODE_PRIVATE).edit().putBoolean("enabled", enabled).apply()
                Toast.makeText(this@MainActivity, if (enabled) "Security Watchdog enabled" else "Security Watchdog paused", Toast.LENGTH_SHORT).show()
            }
        }
        val watchdogInfo = TextView(this).apply {
            text = "WATCHDOG + POLYMORPHIC MALWARE AI ASSISTANT\nAndroid install-event monitoring checks newly installed apps, identifies Google Play versus other/unverified install sources, analyzes the APK locally for packing, high-entropy DEX, dynamic loading and encrypted-payload indicators, and sends a high-priority notification that can appear on the lock screen (subject to Android notification/privacy settings). It cannot identify the human who tapped Install. The “AI assistant” is an explainable on-device heuristic analyzer, not a trained ML model; polymorphic malware detection is not guaranteed and is not a certified antivirus verdict."
            textSize = 13f
            setPadding(0, 8, 0, 12)
        }
        val learn = Button(this).apply {
            text = "Teach the local AI from scan feedback"
            setOnClickListener { showTrainingDialog() }
        }
        val trainingStatus = TextView(this).apply {
            textSize = 12f
            setPadding(0, 4, 0, 8)
            text = "Local learning: ${trainingExamples().size} feedback examples stored on this phone."
        }
        val emailFeedback = Button(this).apply {
            text = "Email feedback / improvement report"
            setOnClickListener { emailFeedbackReport() }
        }
        val webAssistant = Button(this).apply {
            text = "Open Ninjuku • AI research & API pairing"
            setOnClickListener { showIntegratedAiDialog() }
        }
        val subscriptions = Button(this).apply {
            text = "TheUnkwn Premium Subscriptions"
            setOnClickListener { showSubscriptionPage() }
        }
        val export = Button(this).apply {
            text = "Export scan report"
            setOnClickListener { exportReport() }
        }
        output = TextView(this).apply {
            textSize = 13f
            setTextIsSelectable(true)
            text = "Ready. Tap SCAN ENTIRE PHONE and approve the requested Android permissions."
        }
        scanStatus = TextView(this).apply { text = "Ready to scan"; textSize = 17f; setPadding(16,16,16,16) }
        scanProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { isIndeterminate = true; visibility = android.view.View.GONE; contentDescription = "Scan in progress" }
        pauseButton = Button(this).apply { text = "Pause scan"; isEnabled = false; setOnClickListener {
            synchronized(scanLock) { paused = !paused; if (!paused) scanLock.notifyAll() }
            text = if (paused) "Resume scan" else "Pause scan"
            scanStatus.text = if (paused) "Scan paused" else "TheUnkwn is scanning"
        } }
        stopButton = Button(this).apply { text = "Stop scan"; isEnabled = false; setOnClickListener { stopScan(); scanStatus.text = "Stopping scan…"; isEnabled = false; pauseButton.isEnabled = false } }
        val aiResults = TextView(this).apply { text = "Experimental offline permission model. Not a malware verdict."; setTextIsSelectable(true) }
        val chat = EditText(this).apply { hint = "Ask about scan results or permissions"; minLines = 2 }
        val chatAnswer = TextView(this).apply { text = "Offline security help (rule-based, not a language model)." }
        val aiScan = Button(this).apply { text = "Ninjuku offline AI scan"; setOnClickListener { runNinjukuScan(aiResults) } }
        val ask = Button(this).apply { text = "Ask Ninjuku offline"; setOnClickListener {
            val q = chat.text.toString().lowercase(Locale.ROOT)
            chatAnswer.text = when {
                q.contains("scan") || q.contains("result") -> aiResults.text.toString()
                q.contains("permission") || q.contains("spy") -> "Sensitive permissions can indicate privacy risk, but do not prove spying. Review granted permissions in Android Settings."
                q.contains("freeze") -> "Threat Freeze isolates network traffic; it does not stop local recording."
                else -> "I can explain scan results, permissions and Threat Freeze offline. For open-ended questions use optional AI research."
            }
        } }
        val pages = linkedMapOf<String, List<android.view.View>>(
            "Home" to listOf(ImageView(this).apply { setImageResource(R.drawable.home_logo); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER }, intro),
            "Scanner" to listOf(scanButton, scanStatus, scanProgress, pauseButton, stopButton, folder, Button(this).apply { text = "Import trusted SHA-256 signatures"; setOnClickListener { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 92) } }, output),
            "Watchdog" to listOf(watchdog, watchdogInfo, Button(this).apply { text = "Network activity"; setOnClickListener { showNetworkActivity() } }, Button(this).apply { text = "Refresh online threat intelligence"; setOnClickListener { isEnabled = false; executor.execute { val result = LiveIntelligence.refresh(this@MainActivity); runOnUiThread { isEnabled = true; AlertDialog.Builder(this@MainActivity).setTitle("Intelligence update").setMessage(result).setPositiveButton("Close", null).show() } } } }, Button(this).apply { text = "Threat Freeze / network isolation"; setOnClickListener { showThreatFreeze() } }),
            "Ninjuku" to listOf(android.widget.ImageView(this).apply { setImageResource(R.drawable.ninjuku_company_intro); adjustViewBounds = true; scaleType = android.widget.ImageView.ScaleType.FIT_CENTER; contentDescription = "Powered by PocketRealmStudios, Where trust is earned!" }, chat, ask, chatAnswer, Button(this).apply { text = "Ask Ninjuku online (dual AI)"; setOnClickListener { showNinjukuGateway() } }, aiScan, aiResults, webAssistant, learn, trainingStatus, Button(this).apply { text = "Learning status / reset"; setOnClickListener { AlertDialog.Builder(this@MainActivity).setTitle("Ninjuku learning").setMessage(adaptive.status()).setNegativeButton("Close", null).setPositiveButton("Reset model") { _, _ -> adaptive.reset() }.show() } }, emailFeedback),
            "Reports" to listOf(Button(this).apply { text = "Review potential threats"; setOnClickListener { showThreatResults() } }, quarantine, restore, export, Button(this).apply { text = "View technical scan report"; setOnClickListener { AlertDialog.Builder(this@MainActivity).setTitle("Technical report").setMessage(synchronized(lines) { lines.takeLast(700).joinToString("\n") }).setPositiveButton("Close", null).show() } }),
            "Settings" to listOf(Button(this).apply { text = "Choose personal background (regular pages only)"; setOnClickListener { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 93) } }, Button(this).apply { text = "Restore default background"; setOnClickListener { File(filesDir, "custom_background.png").delete(); applyThemeBackground() } }, readme),
            "Premium & Ads" to listOf(subscriptions, Button(this).apply { text = "Load test advertisement"; setOnClickListener { showTestAd() } })
        )
        usageLabel = TextView(this).apply { textSize = 15f; setTextColor(Color.rgb(242,211,143)); setPadding(8,8,8,8); setBackgroundColor(0xEE350B15.toInt()) }
        layout.addView(title); layout.addView(studioMark); layout.addView(usageLabel)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val navScroll = HorizontalScrollView(this).apply { addView(nav) }
        layout.addView(navScroll)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12,12,12,12) }
        val scroll = ScrollView(this).apply { isFillViewport = true; isVerticalScrollBarEnabled = true; isScrollbarFadingEnabled = false; addView(body) }
        layout.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        fun showPage(name: String) {
            body.removeAllViews()
            currentPage = name
            applyThemeBackground()
            body.addView(TextView(this).apply { text = name.uppercase(Locale.US); textSize = 22f; setTextColor(Color.rgb(242,211,143)); setBackgroundColor(0xEE350B15.toInt()) })
            pages.getValue(name).forEach { view ->
                if (view is TextView && view !is Button) { view.setTextColor(Color.WHITE); view.setBackgroundColor(if (name == "Premium & Ads") 0xEE101018.toInt() else 0xEE350B15.toInt()) }
                body.addView(view)
            }
            if (name == "Home") pages.keys.filter { it != "Home" }.forEach { destination ->
                body.addView(Button(this).apply { text = destination; setOnClickListener { showPage(destination) } })
            }
            styleScanBar()
            scroll.scrollTo(0,0)
            refreshUsage()
        }
        pages.keys.forEach { name -> nav.addView(Button(this).apply { text = name; setOnClickListener { showPage(name) } }) }
        setContentView(layout)
        showPage("Home")
        clock.post(tick)
    }

    private fun applyThemeBackground() {
        if (!ThemePolicy.allowsCustom(currentPage)) {
            themeLayout.setBackgroundResource(R.drawable.brand_backdrop)
            return
        }
        val file = File(filesDir, "custom_background.png")
        val bitmap = if (file.isFile) android.graphics.BitmapFactory.decodeFile(file.absolutePath) else null
        if (bitmap != null) themeLayout.background = android.graphics.drawable.BitmapDrawable(resources, bitmap).apply { gravity = android.view.Gravity.FILL }
        else themeLayout.setBackgroundResource(R.drawable.brand_backdrop)
    }

    private fun runNinjukuScan(result: TextView) {
        if (!startUse("scan")) return
        result.text = "Reviewing visible installed apps offline…"
        executor.execute {
            try {
                val apps = packageManager.getInstalledApplications(0)
                var skipped = 0
                val findings = mutableListOf<String>()
                for (app in apps) {
                    val permissions = try { packageManager.getPackageInfo(app.packageName, PackageManager.GET_PERMISSIONS).requestedPermissions?.toSet() ?: emptySet() } catch (_: Exception) { skipped++; continue }
                    val score = NinjukuPresence.score(permissions)
                    if (score >= 0.9) findings.add("${app.packageName}: research score ${String.format(Locale.US, "%.2f", score)}")
                }
                runOnUiThread {
                    result.text = "Experimental permission review: ${apps.size - skipped} evaluated, $skipped unavailable, ${findings.size} flagged for review. Not proof of malware; unflagged apps are not certified safe.\n" + findings.joinToString("\n")
                    finishUse("scan", true)
                }
            } catch (_: Exception) { runOnUiThread { result.text = "AI scan failed"; finishUse("scan", false) } }
        }
    }

    private fun beginFullScan() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (!Environment.isExternalStorageManager()) {
                waitingForAllFilesPermission = true
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                        data = Uri.parse("package:$packageName")
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
                Toast.makeText(this, "Allow all-files access, return here, then tap SCAN ENTIRE PHONE again.", Toast.LENGTH_LONG).show()
                return
            }
            runFullScan()
        } else if (Build.VERSION.SDK_INT == 29) {
            Toast.makeText(this, "Android 10 restricts broad storage scans. Choose the shared-storage root with the folder picker.", Toast.LENGTH_LONG).show()
            chooseFolder()
        } else {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 70)
            } else runFullScan()
        }
    }

    override fun onResume() {
        super.onResume()
        if (waitingForAllFilesPermission && Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()) {
            waitingForAllFilesPermission = false
            Toast.makeText(this, "All-files access granted. Tap SCAN ENTIRE PHONE to start.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 71) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                Toast.makeText(this, "Watchdog notifications enabled", Toast.LENGTH_SHORT).show()
            else Toast.makeText(this, "Notifications are disabled. Enable them in Android Settings to receive Watchdog alerts.", Toast.LENGTH_LONG).show()
        }
        if (requestCode == 70) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) runFullScan()
            else addLine("Storage permission denied. The file scan cannot run without read access.")
        }
    }

    private fun runFullScan() {
        if (!startUse("scan")) return
        scanButton.isEnabled = false
        lines.clear(); threatApps.clear()
        synchronized(quarantineCandidates) { quarantineCandidates.clear() }
        startScanDisplay()
        executor.execute {
            var completed = false
            try {
            addLine("DEVICE AUDITOR - FULL SCAN")
            addLine("Started: ${timestamp()}")
            addLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            addLine("")
            scanInstalledApps()
            addLine("")
            scanSharedStorage()
            addLine("")
            addLine("Scan finished: ${timestamp()}")
            addLine("Review flags are indicators only, not a malware verdict. Files are not changed unless you explicitly use Quarantine flagged files.")
            completed = true
            } catch (_: ScanStopped) { addLine("Scan stopped by user.") } catch (e: Exception) { addLine("Scan failed: ${e.message}") } finally {
                runOnUiThread { endScanDisplay(completed); finishUse("scan", completed && !stopped) }
            }
        }
    }

    private fun scanInstalledApps() {
        addLine("=== INSTALLED APPLICATION INVENTORY ===")
        val pm = packageManager
        val apps = try {
            if (Build.VERSION.SDK_INT >= 33) pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
            else getInstalledApplicationsLegacy(pm)
        } catch (e: Exception) {
            addLine("Could not read installed-app inventory: ${e.message}")
            throw IllegalStateException("App inventory unavailable", e)
        }
        addLine("Packages visible to this app: ${apps.size}")
        val enabledAccessibilityPackages = try {
            Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?.split(":")?.mapNotNull { component -> component.substringBefore('/').takeIf { it.isNotBlank() } }?.toSet() ?: emptySet()
        } catch (_: Exception) { emptySet() }
        val activeAdminPackages = try {
            (getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager).activeAdmins
                ?.map { it.packageName }?.toSet() ?: emptySet()
        } catch (_: Exception) { emptySet() }
        var reviewCount = 0
        val currentSnapshots = linkedMapOf<String, Set<String>>()
        val snapshotPrefs = getSharedPreferences("privacy_exposure_baseline", MODE_PRIVATE)
        apps.sortedBy { it.packageName.lowercase(Locale.ROOT) }.forEach { info ->
            val label = try { pm.getApplicationLabel(info).toString() } catch (_: Exception) { "" }
            checkpoint(label.ifBlank { info.packageName })
            val system = (info.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
            val launchable = try { pm.getLaunchIntentForPackage(info.packageName) != null } catch (_: Exception) { false }
            val enabled = info.enabled
            val installer = try {
                if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(info.packageName).installingPackageName
                else getInstallerLegacy(pm, info.packageName)
            } catch (_: Exception) { null }
            val flags = mutableListOf<String>()
            // Inspect installed APK files where Android exposes a readable path and the bounded scanner accepts the size.
            val installedApkPaths = listOfNotNull(info.sourceDir) + (info.splitSourceDirs?.toList() ?: emptyList())
            installedApkPaths.distinct().forEach { apkPath ->
                scanFileWithLocalEngine(File(apkPath)).forEach { finding -> flags.add("INSTALLED APP APK: $finding") }
            }
            if (installedApkPaths.isNotEmpty()) {
                val adaptive = AdaptiveMalwareAssistant.inspect(File(installedApkPaths.first()))
                if (LiveIntelligence.matches(this, adaptive.sha256)) flags.add("LIVE THREATFOX HASH MATCH / REVIEW")
                if (adaptive.score >= 3) flags.add("ADAPTIVE MALWARE REVIEW SCORE ${adaptive.score}: ${adaptive.details.joinToString("; ")}")
            }
            val requested = try {
                if (Build.VERSION.SDK_INT >= 33) pm.getPackageInfo(info.packageName, PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong())).requestedPermissions?.toSet() ?: emptySet()
                else getRequestedPermissionsLegacy(pm, info.packageName)
            } catch (_: Exception) { emptySet<String>() }
            val privacyPermissions = linkedMapOf(
                "android.permission.READ_SMS" to "READ SMS", "android.permission.RECEIVE_SMS" to "RECEIVE SMS",
                "android.permission.SEND_SMS" to "SEND SMS", "android.permission.READ_CALL_LOG" to "READ CALL LOG",
                "android.permission.WRITE_CALL_LOG" to "WRITE CALL LOG", "android.permission.READ_CONTACTS" to "READ CONTACTS",
                "android.permission.READ_PHONE_STATE" to "PHONE STATE", "android.permission.RECORD_AUDIO" to "MICROPHONE",
                "android.permission.CAMERA" to "CAMERA", "android.permission.ACCESS_FINE_LOCATION" to "PRECISE LOCATION",
                "android.permission.ACCESS_COARSE_LOCATION" to "LOCATION", "android.permission.READ_EXTERNAL_STORAGE" to "SHARED FILES",
                "android.permission.MANAGE_EXTERNAL_STORAGE" to "ALL FILES ACCESS", "android.permission.READ_MEDIA_IMAGES" to "PHOTOS",
                "android.permission.READ_MEDIA_VIDEO" to "VIDEOS", "android.permission.READ_MEDIA_AUDIO" to "AUDIO"
            )
            val privacyFlags = privacyPermissions.filterKeys { requested.contains(it) }.values
            val granted = privacyPermissions.filterKeys { pm.checkPermission(it, info.packageName) == PackageManager.PERMISSION_GRANTED }.values
            if (granted.isNotEmpty()) flags.add("CURRENTLY GRANTED SENSITIVE PERMISSIONS: ${granted.joinToString()}")
            if (privacyFlags.isNotEmpty()) flags.add("PRIVACY PERMISSIONS: ${privacyFlags.joinToString("/")}")
            val serviceAndReceiverInfo = try {
                if (Build.VERSION.SDK_INT >= 33) pm.getPackageInfo(info.packageName, PackageManager.PackageInfoFlags.of((PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS).toLong()))
                else getComponentInfoLegacy(pm, info.packageName)
            } catch (_: Exception) { null }
            val declaresAccessibility = serviceAndReceiverInfo?.services?.any { it.permission == "android.permission.BIND_ACCESSIBILITY_SERVICE" } == true
            val declaresDeviceAdmin = serviceAndReceiverInfo?.receivers?.any { it.permission == "android.permission.BIND_DEVICE_ADMIN" } == true
            if (declaresAccessibility) flags.add("DECLARES ACCESSIBILITY SERVICE")
            if (info.packageName in enabledAccessibilityPackages) flags.add("ACCESSIBILITY SERVICE CURRENTLY ENABLED / REVIEW")
            if (declaresDeviceAdmin) flags.add("DECLARES DEVICE-ADMIN RECEIVER")
            if (info.packageName in activeAdminPackages) flags.add("ACTIVE DEVICE ADMIN / REVIEW")
            val currentExposure = (requested.filter { it in setOf(
                "android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.SEND_SMS",
                "android.permission.READ_CALL_LOG", "android.permission.READ_CONTACTS", "android.permission.RECORD_AUDIO",
                "android.permission.CAMERA", "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION",
                "android.permission.MANAGE_EXTERNAL_STORAGE", "android.permission.SYSTEM_ALERT_WINDOW"
            ) } + listOfNotNull(
                if (declaresAccessibility) "SPECIAL:DECLARES_ACCESSIBILITY" else null,
                if (info.packageName in enabledAccessibilityPackages) "SPECIAL:ACCESSIBILITY_ENABLED" else null,
                if (declaresDeviceAdmin) "SPECIAL:DECLARES_DEVICE_ADMIN" else null,
                if (info.packageName in activeAdminPackages) "SPECIAL:DEVICE_ADMIN_ACTIVE" else null
            )).toSet()
            currentSnapshots[info.packageName] = currentExposure
            val previousExposure = snapshotPrefs.getStringSet("app:${info.packageName}", emptySet()) ?: emptySet()
            if (snapshotPrefs.contains("app:${info.packageName}")) {
                val newlyExposed = currentExposure - previousExposure
                if (newlyExposed.isNotEmpty()) flags.add("NEW PRIVACY EXPOSURE SINCE BASELINE: ${newlyExposed.joinToString()}")
            }
            var riskScore = 0
            riskScore += requested.count { it in setOf("android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.READ_CALL_LOG", "android.permission.READ_CONTACTS") } * 2
            riskScore += requested.count { it in setOf("android.permission.ACCESS_FINE_LOCATION", "android.permission.RECORD_AUDIO", "android.permission.CAMERA", "android.permission.MANAGE_EXTERNAL_STORAGE") }
            if (declaresAccessibility) riskScore += 2
            if (info.packageName in enabledAccessibilityPackages) riskScore += 4
            if (declaresDeviceAdmin) riskScore += 1
            if (info.packageName in activeAdminPackages) riskScore += 3
            if (!system && installer.isNullOrBlank()) riskScore += 1
            if (riskScore >= 5) flags.add("ELEVATED PRIVACY RISK SCORE: $riskScore")
            if (!system && info.packageName != packageName && (riskScore >= 5 || flags.any { it.contains("MALWARE REVIEW SCORE") || it.contains("HASH MATCH") || it.contains("SHA-256 MATCH") })) threatApps[info.packageName] = label.ifBlank { info.packageName }
            if (!system) flags.add("USER-APP")
            if (!launchable) flags.add("NO-LAUNCHER-ENTRY / REVIEW")
            if (label.isBlank()) flags.add("EMPTY-APP-LABEL / REVIEW")
            if (!enabled) flags.add("DISABLED")
            if (!system && installer.isNullOrBlank()) flags.add("INSTALLER-UNKNOWN")
            if (flags.any { it.contains("REVIEW") || it.contains("ELEVATED PRIVACY RISK") || it == "INSTALLER-UNKNOWN" || it.startsWith("PRIVACY PERMISSIONS") }) reviewCount++
            addLine("${if (system) "[SYSTEM]" else "[USER]"} ${label.ifBlank { "[NO APP LABEL]" }} | ${info.packageName}")
            addLine("  Status: ${flags.ifEmpty { listOf("NORMAL INVENTORY ENTRY") }.joinToString(", ")} | Installer: ${installer ?: "not reported"}")
        }
        addLine("Apps/packages marked for manual review: $reviewCount")
        addLine("Stalkerware indicators: enabled accessibility packages=${enabledAccessibilityPackages.size}; active device-admin packages=${activeAdminPackages.size}.")
        addLine("Risk score weighs combinations of sensitive permissions and active special access. Legitimate password managers, accessibility tools, device-management apps and security products may score highly; verify publisher and purpose before taking action.")
        addLine("Privacy review: requested permissions are indicators only. Android may grant permissions at runtime or through special settings; requested does not necessarily mean currently granted or actively abused.")
        val hasBaseline = snapshotPrefs.all.keys.any { it.startsWith("app:") }
        if (hasBaseline) {
            val driftCount = currentSnapshots.count { (pkg, now) ->
                val old = snapshotPrefs.getStringSet("app:$pkg", emptySet()) ?: emptySet()
                now.any { it !in old }
            }
            val removedApps = snapshotPrefs.all.keys.filter { it.startsWith("app:") }.map { it.removePrefix("app:") }.filter { it !in currentSnapshots }
            addLine("EXPOSURE TRAIL: $driftCount app(s) have newly added sensitive capabilities since the saved baseline; ${removedApps.size} previously inventoried package(s) are no longer visible/installed.")
            if (driftCount == 0) addLine("No new declared sensitive capabilities were detected compared with the previous scan baseline.")
        } else addLine("EXPOSURE TRAIL: this is the first baseline scan. A baseline has been saved for future change detection.")
        val editor = snapshotPrefs.edit()
        snapshotPrefs.all.keys.filter { it.startsWith("app:") }.forEach { key ->
            val pkg = key.removePrefix("app:")
            if (pkg !in currentSnapshots) editor.remove(key)
        }
        currentSnapshots.forEach { (pkg, exposure) -> editor.putStringSet("app:$pkg", exposure) }
        editor.apply()
        addLine("EXPOSURE TRAIL compares each app's declared sensitive permissions and visible special-access indicators across scans. It is a device-local change log, not proof of data exfiltration.")
        addLine("Note: 'unknown' or 'no launcher entry' does not mean malicious; Android includes background components and services.")
    }

    @Suppress("DEPRECATION")
    private fun getComponentInfoLegacy(pm: PackageManager, packageName: String) =
        pm.getPackageInfo(packageName, PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS)

    @Suppress("DEPRECATION")
    private fun getInstalledApplicationsLegacy(pm: PackageManager) = pm.getInstalledApplications(0)

    @Suppress("DEPRECATION")
    private fun getRequestedPermissionsLegacy(pm: PackageManager, packageName: String): Set<String> =
        pm.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS).requestedPermissions?.toSet() ?: emptySet()

    @Suppress("DEPRECATION")
    private fun getInstallerLegacy(pm: PackageManager, packageName: String) = pm.getInstallerPackageName(packageName)

    private fun scanSharedStorage() {
        addLine("=== SHARED STORAGE FILE SCAN ===")
        if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
            addLine("Skipped: Android all-files access has not been granted.")
            return
        }
        val roots = linkedSetOf<String>()
        roots.add(Environment.getExternalStorageDirectory().absolutePath)
        // Include removable/shared volumes when Android exposes their shared root.
        getExternalFilesDirs(null).filterNotNull().forEach { appDir ->
            var root = appDir
            repeat(4) { root = root.parentFile ?: root }
            roots.add(root.absolutePath)
        }
        var fileCount = 0L
        var dirCount = 0L
        var bytes = 0L
        var errors = 0L
        var flagged = 0L
        val seen = HashSet<String>()
        val stack = ArrayDeque<File>()
        roots.map { File(it) }.filter { it.exists() && it.isDirectory }.forEach { stack.add(it) }
        addLine("Storage roots attempted: ${roots.joinToString()}")
        while (stack.isNotEmpty()) {
            val dir = stack.removeLast()
            val canonical = try { dir.canonicalPath } catch (_: Exception) { errors++; continue }
            if (!seen.add(canonical)) continue
            val children = try { dir.listFiles() } catch (_: SecurityException) { null } catch (_: Exception) { null }
            if (children == null) { errors++; continue }
            dirCount++
            for (item in children) {
                checkpoint(item.absolutePath)
                try {
                    if (item.isDirectory) {
                        // Android data contains other apps' private data and is not part of shared-file auditing.
                        if (item.name == "data" && dir.name == "Android") {
                            addLine("[PROTECTED AREA SKIPPED] ${item.absolutePath}")
                            continue
                        }
                        stack.add(item)
                    } else if (item.isFile) {
                        fileCount++
                        val length = try { item.length() } catch (_: Exception) { 0L }
                        bytes += length
                        val name = item.name
                        val lower = name.lowercase(Locale.ROOT)
                        val flags = mutableListOf<String>()
                        if (name.isBlank()) flags.add("MISSING NAME")
                        if (name.startsWith(".")) flags.add("HIDDEN")
                        if (length == 0L) flags.add("EMPTY FILE")
                        if (lower.endsWith(".apk")) flags.add("APK PACKAGE")
                        if (lower.endsWith(".obb")) flags.add("OBB GAME DATA")
                        if (lower.endsWith(".dex") || lower.endsWith(".so") || lower.endsWith(".jar")) flags.add("EXECUTABLE-CODE TYPE")
                        if (!name.contains('.') && length > 0L) flags.add("NO EXTENSION")
                        val malwareFindings = scanFileWithLocalEngine(item)
                        flags.addAll(malwareFindings)
                        if (malwareFindings.any { it.contains("EICAR") || it.contains("SUSPICIOUS SCRIPT PATTERN") }) {
                            synchronized(quarantineCandidates) {
                                quarantineCandidates.add(QuarantineCandidate(name, { try { item.inputStream() } catch (_: Exception) { null } }, { try { item.delete() } catch (_: Exception) { false } }))
                            }
                        }
                        if (flags.isNotEmpty()) {
                            flagged++
                            addLine("[${flags.joinToString(", ")}] ${item.absolutePath} | $length bytes")
                        }
                    }
                } catch (_: SecurityException) { errors++ }
                catch (_: Exception) { errors++ }
            }
            if (dirCount % 100L == 0L) publishProgress("Scanning storage… $fileCount files checked")
        }
        addLine("Storage summary: $fileCount files in $dirCount directories; ${humanBytes(bytes)} total; $flagged flagged; $errors inaccessible/error entries.")
        addLine("Android may block protected app-private folders, system partitions, and some removable-volume locations even with permissions. These are not included in the scan.")
    }

    // Local signature + heuristic engine. Deliberately bounded to keep scans responsive.
    private fun scanFileWithLocalEngine(file: File): List<String> {
        val findings = mutableListOf<String>()
        val length = try { file.length() } catch (_: Exception) { return findings }
        if (length <= 0L) return findings
        signatures.check { file.inputStream() }?.let { findings.add(it) }
        if (length > 25L * 1024L * 1024L) return findings + if (file.extension.equals("apk", true)) scanApkArchive(file) else listOf("CONTENT SCAN SKIPPED: file exceeds 25 MiB")
        val bytes = try { file.inputStream().use { it.readBytes() } } catch (_: Exception) { return findings }
        if (containsBytes(bytes, "X5O!P%@AP[4\\PZX54(P^)7CC)7}\$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!\$H+H*".toByteArray(Charsets.US_ASCII))) {
            findings.add("MALWARE SIGNATURE MATCH: EICAR TEST FILE (NOT LIVE MALWARE)")
        }
        val ext = file.extension.lowercase(Locale.ROOT)
        if (ext in setOf("sh", "bash", "py", "js", "bat", "cmd", "ps1", "vbs")) {
            val text = bytes.toString(Charsets.UTF_8).lowercase(Locale.ROOT)
            if ((text.contains("curl ") || text.contains("wget ")) && (text.contains("|sh") || text.contains("| sh") || text.contains("bash -c"))) {
                findings.add("SUSPICIOUS SCRIPT PATTERN: DOWNLOAD-AND-EXECUTE")
            }
            if (text.contains("base64 -d") && (text.contains("chmod +x") || text.contains("sh -c"))) {
                findings.add("SUSPICIOUS SCRIPT PATTERN: DECODE-AND-EXECUTE")
            }
        }
        if (ext == "apk" || bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4b.toByte()) {
            findings.addAll(scanApkArchive(file))
        }
        adaptive.inspect(bytes, findings)
        return findings.distinct()
    }

    private fun scanFileWithLocalEngine(uri: Uri): List<String> {
        val findings = mutableListOf<String>()
        signatures.check { contentResolver.openInputStream(uri) ?: error("Unavailable") }?.let { findings.add(it) }
        val bytes = try {
            contentResolver.openInputStream(uri)?.use { input ->
                val out = ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (total < 25 * 1024 * 1024) {
                    val n = input.read(buffer)
                    if (n <= 0) break
                    val allowed = minOf(n, 25 * 1024 * 1024 - total)
                    out.write(buffer, 0, allowed); total += allowed
                }
                out.toByteArray()
            }
        } catch (_: Exception) { null } ?: return findings
        if (containsBytes(bytes, "X5O!P%@AP[4\\PZX54(P^)7CC)7}\$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!\$H+H*".toByteArray(Charsets.US_ASCII)))
            findings.add("MALWARE SIGNATURE MATCH: EICAR TEST FILE (NOT LIVE MALWARE)")
        val text = bytes.toString(Charsets.UTF_8).lowercase(Locale.ROOT)
        if ((text.contains("curl ") || text.contains("wget ")) && (text.contains("|sh") || text.contains("| sh") || text.contains("bash -c")))
            findings.add("SUSPICIOUS SCRIPT PATTERN: DOWNLOAD-AND-EXECUTE")
        adaptive.inspect(bytes, findings)
        return findings
    }

    private fun scanApkArchive(file: File): List<String> {
        val findings = mutableListOf<String>()
        try {
            ZipFile(file).use { zip ->
                val names = zip.entries().asSequence().map { it.name.lowercase(Locale.ROOT) }.toList()
                if (names.any { it.startsWith("assets/") && (it.endsWith(".sh") || it.endsWith(".ps1") || it.endsWith(".bat")) })
                    findings.add("APK CONTAINS EMBEDDED SCRIPT FILES / REVIEW")
                val info = try {
                    if (Build.VERSION.SDK_INT >= 33) packageManager.getPackageArchiveInfo(file.absolutePath, PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()))
                    else getArchiveInfoLegacy(file)
                } catch (_: Exception) { null }
                val perms = info?.requestedPermissions?.toSet() ?: emptySet()
                val sensitive = perms.intersect(setOf("android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.READ_CALL_LOG", "android.permission.READ_CONTACTS", "android.permission.RECORD_AUDIO", "android.permission.ACCESS_FINE_LOCATION", "android.permission.MANAGE_EXTERNAL_STORAGE", "android.permission.SYSTEM_ALERT_WINDOW", "android.permission.REQUEST_INSTALL_PACKAGES"))
                if (sensitive.isNotEmpty()) findings.add("APK REQUESTS SENSITIVE CAPABILITIES: ${sensitive.joinToString()}")
                // Scan only bounded DEX entries for high-signal stalkerware/loader markers.
                var markerHits = 0
                zip.entries().asSequence().filter { it.name.matches(Regex("classes(\\d+)?\\.dex")) }.take(3).forEach { entry ->
                    if (entry.size in 1..(12L * 1024L * 1024L)) {
                        val dexBytes = zip.getInputStream(entry).use { it.readBytes() }
                        val dexText = dexBytes.toString(Charsets.ISO_8859_1)
                        listOf("BIND_ACCESSIBILITY_SERVICE", "BIND_DEVICE_ADMIN", "READ_SMS", "READ_CALL_LOG", "SYSTEM_ALERT_WINDOW", "REQUEST_INSTALL_PACKAGES").forEach { marker ->
                            if (dexText.contains(marker)) markerHits++
                        }
                    }
                }
                if (markerHits >= 3) findings.add("APK CODE CONTAINS MULTIPLE HIGH-RISK API MARKERS / REVIEW")
            }
        } catch (_: Exception) { /* Non-ZIP or unreadable file: no verdict */ }
        return findings
    }

    @Suppress("DEPRECATION")
    private fun getArchiveInfoLegacy(file: File) = packageManager.getPackageArchiveInfo(file.absolutePath, PackageManager.GET_PERMISSIONS)

    private fun containsBytes(haystack: ByteArray, needle: ByteArray): Boolean {
        if (needle.isEmpty() || haystack.size < needle.size) return false
        outer@ for (i in 0..haystack.size - needle.size) {
            for (j in needle.indices) if (haystack[i + j] != needle[j]) continue@outer
            return true
        }
        return false
    }

    private fun addLine(value: String) {
        synchronized(lines) { lines.add(value) }
        publishProgress(value)
    }

    private fun publishProgress(value: String) {
        if (scanning) return
        runOnUiThread {
            output.text = synchronized(lines) { lines.takeLast(700).joinToString("\n") }
        }
    }

    private fun showNetworkActivity() {
        val rx = android.net.TrafficStats.getTotalRxBytes(); val tx = android.net.TrafficStats.getTotalTxBytes()
        val cm = getSystemService(android.net.ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        AlertDialog.Builder(this).setTitle("Network activity").setMessage("Connected: ${caps != null}\nReceived since boot: ${if (rx >= 0) humanBytes(rx) else "Unavailable"}\nSent since boot: ${if (tx >= 0) humanBytes(tx) else "Unavailable"}\nDevice totals only. Traffic volume is not evidence of spyware. No packet contents are collected.").setPositiveButton("Close", null).setNeutralButton("Android data usage") { _, _ -> try { startActivity(Intent(Settings.ACTION_DATA_USAGE_SETTINGS)) } catch (_: Exception) {} }.show()
    }
    private fun showThreatResults() {
        if (scanning) return
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,20,20,20); setBackgroundColor(0xFFFFE5E5.toInt()) }
        val title = TextView(this).apply { text = "POTENTIAL THREATS — REVIEW REQUIRED"; setTextColor(Color.BLACK); setTypeface(null, Typeface.BOLD); textSize = 19f }
        panel.addView(title)
        val apps = threatApps.entries.sortedBy { it.value }
        if (apps.isEmpty()) panel.addView(TextView(this).apply { text = "No app review candidates recorded. This is not a clean-device guarantee."; setTextColor(Color.BLACK) })
        for ((pkg, label) in apps) panel.addView(Button(this).apply { text = "$label\n$pkg"; setTextColor(Color.BLACK); setTypeface(null, Typeface.BOLD); setBackgroundColor(0xFFFFD0D0.toInt()); setOnClickListener { reviewApp(pkg) } })
        AlertDialog.Builder(this).setView(ScrollView(this).apply { addView(panel) }).setPositiveButton("Close", null).show()
    }
    private fun reviewApp(pkg: String) {
        val info = try { packageManager.getApplicationInfo(pkg, 0) } catch (_: Exception) { return }
        if (pkg == packageName || info.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) return
        AlertDialog.Builder(this).setTitle("Review ${packageManager.getApplicationLabel(info)}").setItems(arrayOf("App settings / uninstall", "Freeze network access", "View technical evidence")) { _, index ->
            when (index) {
                0 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
                1 -> AlertDialog.Builder(this).setTitle("Confirm network isolation").setMessage("Block this app's network access? This replaces the existing VPN isolation selection and does not stop local execution.").setNegativeButton("Cancel", null).setPositiveButton("Freeze") { _, _ ->
                    getSharedPreferences("threat_freeze", MODE_PRIVATE).edit().putStringSet("packages", setOf(pkg)).apply()
                    val consent = android.net.VpnService.prepare(this); if (consent != null) startActivityForResult(consent, 91) else startThreatFreeze()
                }.show()
                2 -> AlertDialog.Builder(this).setTitle("Evidence").setMessage(synchronized(lines) { val i = lines.indexOfFirst { it.endsWith("| $pkg") }; if (i >= 0) lines.drop(i).take(2).joinToString("\n") else "Evidence unavailable" }).setPositiveButton("Close", null).show()
            }
        }.show()
    }
    private fun showThreatFreeze() {
        val apps = packageManager.getInstalledApplications(0).filter {
            it.packageName != packageName && (it.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) == 0
        }.sortedBy { packageManager.getApplicationLabel(it).toString() }
        if (apps.isEmpty()) { Toast.makeText(this, "No eligible user apps found", Toast.LENGTH_LONG).show(); return }
        val labels = apps.map { "${packageManager.getApplicationLabel(it)} (${it.packageName})" }.toTypedArray()
        val selected = BooleanArray(apps.size)
        AlertDialog.Builder(this).setTitle("Threat Freeze: select apps")
            .setMultiChoiceItems(labels, selected) { _, i, checked -> selected[i] = checked }
            .setPositiveButton("Block network") { _, _ ->
                val packages = apps.filterIndexed { i, _ -> selected[i] }.map { it.packageName }
                if (packages.isEmpty()) return@setPositiveButton
                AlertDialog.Builder(this).setTitle("Confirm network isolation")
                    .setMessage("Selected apps will lose network access while the local VPN is active. This replaces any existing VPN. It does not stop local recording or app execution. Only isolate apps you have reviewed.")
                    .setNegativeButton("Cancel", null).setPositiveButton("Continue") { _, _ ->
                        getSharedPreferences("threat_freeze", MODE_PRIVATE).edit().putStringSet("packages", packages.toSet()).apply()
                        val consent = android.net.VpnService.prepare(this)
                        if (consent != null) startActivityForResult(consent, 91) else startThreatFreeze()
                    }.show()
            }.setNeutralButton("Unfreeze all") { _, _ ->
                stopService(Intent(this, ThreatFreezeService::class.java))
                Toast.makeText(this, "Network isolation stopped", Toast.LENGTH_LONG).show()
            }.setNegativeButton("App settings") { _, _ ->
                AlertDialog.Builder(this).setTitle("Review permissions / force stop")
                    .setItems(labels) { _, i -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${apps[i].packageName}"))) }.show()
            }.show()
    }

    private fun startThreatFreeze() {
        try { startForegroundService(Intent(this, ThreatFreezeService::class.java)) }
        catch (e: Exception) { Toast.makeText(this, "Isolation could not start: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun chooseFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        startActivityForResult(intent, pickFolder)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 93) {
            if (resultCode == RESULT_OK) data?.data?.let { uri ->
                try {
                    val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, opts) }
                    require(opts.outWidth > 0 && opts.outHeight > 0)
                    var sample = 1
                    while (maxOf(opts.outWidth, opts.outHeight) / sample > 1600) sample *= 2
                    val bitmap = contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it, null, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }) } ?: error("Invalid image")
                    val temp = File(filesDir, "custom_background.tmp")
                    temp.outputStream().use { require(bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it)) }
                    require(temp.renameTo(File(filesDir, "custom_background.png")))
                    applyThemeBackground()
                } catch (_: Exception) { Toast.makeText(this, "Unable to load background", Toast.LENGTH_LONG).show() }
            }
            return
        }
        if (requestCode == 92) {
            val uri = data?.data
            if (resultCode == RESULT_OK && uri != null) Thread {
                try {
                    val count = contentResolver.openInputStream(uri)?.use { signatures.importHashes(it) } ?: error("Cannot open file")
                    addLine("Imported $count trusted-source hashes. Verify provenance before importing.")
                } catch (e: Exception) { addLine("Signature import failed: ${e.message}") }
            }.start()
            return
        }
        if (requestCode == 91) { if (resultCode == RESULT_OK) startThreatFreeze(); return }
        if (resultCode != RESULT_OK || data?.data == null) return
        if (requestCode == createReport) {
            writeReport(data.data!!)
        } else if (requestCode == restoreFolderRequest) {
            restoreQuarantineTo(data.data!!)
        } else if (requestCode == pickFolder) {
            val uri = data.data!!
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            scanSelectedTree(uri)
        }
    }

    private fun scanSelectedTree(uri: Uri) {
        if (!startUse("scan")) return
        scanButton.isEnabled = false
        lines.clear(); threatApps.clear()
        synchronized(quarantineCandidates) { quarantineCandidates.clear() }
        startScanDisplay()
        executor.execute {
            var completed = false
            try {
            addLine("THEUNKWN COMBINED ANDROID 10 SCAN")
            addLine("Started: ${timestamp()}")
            addLine("Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            addLine("")
            scanInstalledApps()
            addLine("")
            addLine("=== USER-SELECTED FOLDER / LOCAL MALWARE SCAN ===")
            addLine("Selected URI: $uri")
            val root = DocumentFile.fromTreeUri(this, uri) ?: throw IllegalStateException("Selected folder unavailable")
            var count = 0L
            var total = 0L
            var flagged = 0L
            if (root != null) {
                val stack = ArrayDeque<DocumentFile>()
                stack.add(root)
                while (stack.isNotEmpty()) {
                    val dir = stack.removeLast()
                    val children = try { dir.listFiles() } catch (_: Exception) { emptyArray() }
                    for (f in children) {
                        checkpoint(f.name ?: "Unnamed file")
                        if (f.isDirectory) stack.add(f) else {
                            count++
                            val name = f.name ?: "[NO NAME]"
                            val size = f.length()
                            total += size
                            val flags = mutableListOf<String>()
                            if (name == "[NO NAME]" || name.isBlank()) flags.add("MISSING NAME")
                            if (name.startsWith('.')) flags.add("HIDDEN")
                            if (size == 0L) flags.add("EMPTY")
                            if (name.endsWith(".apk", true)) flags.add("APK")
                            if (name.endsWith(".obb", true)) flags.add("OBB")
                            val malwareFindings = scanFileWithLocalEngine(f.uri)
                            flags.addAll(malwareFindings)
                            if (malwareFindings.any { it.contains("EICAR") || it.contains("SUSPICIOUS SCRIPT PATTERN") }) {
                                synchronized(quarantineCandidates) {
                                    quarantineCandidates.add(QuarantineCandidate(name, { try { contentResolver.openInputStream(f.uri) } catch (_: Exception) { null } }, { try { f.delete() } catch (_: Exception) { false } }))
                                }
                            }
                            if (flags.isNotEmpty()) { flagged++; addLine("[${flags.joinToString(", ")}] $name | $size bytes") }
                        }
                    }
                }
            }
            addLine("Folder summary: $count files; ${humanBytes(total)}; $flagged flagged.")
            addLine("Only the selected folder and descendants Android exposed were scanned.")
            addLine("Finished: ${timestamp()}")
            addLine("Local engine limitations: heuristic and signature indicators only; imported SHA-256 signatures plus heuristics; no automatic live feed configured.")
            completed = true
            } catch (_: ScanStopped) { addLine("Scan stopped by user.") } catch (e: Exception) { addLine("Scan failed: ${e.message}") } finally {
                runOnUiThread { endScanDisplay(completed); finishUse("scan", completed && !stopped) }
            }
        }
    }

    private fun confirmQuarantine() {
        val count = synchronized(quarantineCandidates) { quarantineCandidates.size }
        if (count == 0) {
            Toast.makeText(this, "No EICAR or suspicious download-and-execute script findings are queued. Run a scan first.", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Move flagged files to quarantine?")
            .setMessage("TheUnkwn will copy $count detected test-signature or suspicious-script file(s) into its private app storage, verify each copy, then remove the original only when verification succeeds. This does not uninstall or disable installed apps. You can restore quarantined files later. Continue?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Quarantine") { _, _ -> quarantineToPrivateStorage() }
            .show()
    }

    private fun quarantineToPrivateStorage() {
        val candidates = synchronized(quarantineCandidates) { quarantineCandidates.toList() }
        if (candidates.isEmpty()) return
        scanButton.isEnabled = false
        executor.execute {
            val quarantineDir = File(filesDir, "quarantine").apply { if (!exists()) mkdirs() }
            var moved = 0
            var failed = 0
            candidates.forEach { candidate ->
                try {
                    val safeName = candidate.name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "unknown_file" }
                    val destination = File(quarantineDir, "${UUID.randomUUID()}_$safeName")
                    val input = candidate.open()
                    if (input == null) { failed++; addLine("QUARANTINE FAILED (cannot read): ${candidate.name}"); return@forEach }
                    val copiedBytes = input.use { source -> destination.outputStream().use { target -> source.copyTo(target) } }
                    if (copiedBytes > 0L && destination.length() == copiedBytes && candidate.removeOriginal()) {
                        moved++
                        addLine("QUARANTINED AND ORIGINAL REMOVED: ${candidate.name} (${destination.length()} bytes)")
                    } else {
                        destination.delete()
                        failed++
                        addLine("QUARANTINE NOT COMPLETED; original retained: ${candidate.name}")
                    }
                } catch (e: Exception) {
                    failed++
                    addLine("QUARANTINE ERROR for ${candidate.name}: ${e.message}")
                }
            }
            synchronized(quarantineCandidates) { quarantineCandidates.clear() }
            addLine("Quarantine result: $moved moved to private app storage; $failed failed. Installed apps are not quarantined or disabled.")
            addLine("Quarantine files are private to TheUnkwn and are removed if TheUnkwn is uninstalled. Use Restore quarantined files to copy them back to a folder you choose.")
            runOnUiThread { scanButton.isEnabled = true }
        }
    }

    private fun chooseRestoreFolder() {
        val quarantineDir = File(filesDir, "quarantine")
        if (!quarantineDir.exists() || quarantineDir.listFiles().isNullOrEmpty()) {
            Toast.makeText(this, "The quarantine is empty.", Toast.LENGTH_SHORT).show()
            return
        }
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), restoreFolderRequest)
    }

    private fun restoreQuarantineTo(treeUri: Uri) {
        val root = DocumentFile.fromTreeUri(this, treeUri) ?: return
        val quarantineDir = File(filesDir, "quarantine")
        scanButton.isEnabled = false
        executor.execute {
            var restored = 0
            var failed = 0
            quarantineDir.listFiles()?.forEach { source ->
                try {
                    var outputName = source.name
                    var suffix = 1
                    while (root.findFile(outputName) != null) {
                        outputName = "${source.name}-$suffix"
                        suffix++
                    }
                    val target = root.createFile("application/octet-stream", outputName)
                    if (target == null) { failed++; return@forEach }
                    val copiedBytes = source.inputStream().use { input ->
                        contentResolver.openOutputStream(target.uri)?.use { output -> input.copyTo(output) }
                            ?: throw IllegalStateException("Could not write to selected folder")
                    }
                    if (copiedBytes == source.length() && target.length() == copiedBytes) {
                        restored++
                        addLine("RESTORED COPY: $outputName. Quarantine copy retained until you delete it manually.")
                    } else {
                        target.delete(); failed++
                        addLine("RESTORE VERIFICATION FAILED: ${source.name}")
                    }
                } catch (e: Exception) {
                    failed++
                    addLine("RESTORE ERROR for ${source.name}: ${e.message}")
                }
            }
            addLine("Restore result: $restored copied; $failed failed. Quarantine originals were retained.")
            runOnUiThread { scanButton.isEnabled = true }
        }
    }

    // Feedback examples are stored locally. They are not executable rules and never alter APKs.
    private fun trainingExamples(): MutableSet<String> =
        getSharedPreferences("theunkwn_learning", MODE_PRIVATE).getStringSet("examples", emptySet())?.toMutableSet() ?: mutableSetOf()

    private fun showTrainingDialog() {
        val fields = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        val indicator = EditText(this).apply { hint = "App name, package, hash, or detection indicator" }
        val notes = EditText(this).apply { hint = "What did you learn? (optional notes)"; minLines = 2 }
        val label = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Confirmed suspicious", "Likely false positive", "Needs more investigation"))
        }
        fields.addView(TextView(this).apply { text = "Feedback label" })
        fields.addView(label); fields.addView(indicator); fields.addView(notes)
        AlertDialog.Builder(this).setTitle("Teach TheUnkwn")
            .setMessage("Save a labelled example to the on-device learning notebook. This helps build a reviewed training set for future detection updates; it does not retrain a neural network or automatically change detection code.")
            .setView(fields)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save feedback") { _, _ ->
                val key = indicator.text.toString().trim()
                if (key.isBlank()) {
                    Toast.makeText(this, "Enter an app, hash, or detection indicator first.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val record = listOf(timestamp(), label.selectedItem.toString(), key.take(240), notes.text.toString().trim().take(1000)).joinToString(" | ")
                val examples = trainingExamples()
                examples.add(record)
                getSharedPreferences("theunkwn_learning", MODE_PRIVATE).edit().putStringSet("examples", examples).apply()
                addLine("LOCAL LEARNING: saved feedback example — ${label.selectedItem}: $key")
                Toast.makeText(this, "Feedback saved on this phone.", Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun emailFeedbackReport() {
        val examples = trainingExamples().sorted().joinToString("\n").ifBlank { "No labelled training examples saved." }
        val report = buildString {
            append("THEUNKWN FEEDBACK AND IMPROVEMENT REPORT\nCreated: ${timestamp()}\n\n")
            append("APP VERSION: 10.0\nANDROID: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n\n")
            append("LATEST SCAN / NOTES\n")
            synchronized(lines) { append(lines.takeLast(500).joinToString("\n")) }
            append("\n\nLOCAL TRAINING FEEDBACK\n$examples\n")
            val research = getSharedPreferences("theunkwn_learning", MODE_PRIVATE)
                .getStringSet("research_notes", emptySet())?.sorted()?.joinToString("\n")
                .orEmpty().ifBlank { "No research notes saved." }
            append("\n\nWEB RESEARCH QUESTIONS\n$research\n")
            append("\nPlease review these findings for potential future detection-rule improvements. No APK files or private app data are attached.")
        }
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:gtrev8921@gmail.com")
            putExtra(Intent.EXTRA_SUBJECT, "TheUnkwn 10.0 — security feedback and code improvement")
            putExtra(Intent.EXTRA_TEXT, report)
        }
        try {
            startActivity(Intent.createChooser(intent, "Send TheUnkwn feedback by email"))
        } catch (_: Exception) {
            Toast.makeText(this, "No email app is available. Install or configure an email app, then try again.", Toast.LENGTH_LONG).show()
        }
    }

    private fun showIntegratedAiDialog() {
        val prefs = getSharedPreferences("theunkwn_ai", MODE_PRIVATE)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        val mode = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("My OpenAI API key (encrypted on this phone)", "Use my secure AI backend (OpenAI / Gemini)"))
            setSelection(prefs.getInt("ai_mode", 0).coerceIn(0, 1))
        }
        val apiKey = EditText(this).apply {
            hint = "Paste your OpenAI API key (sk-…)"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            textSize = 14f
        }
        val endpoint = EditText(this).apply {
            hint = "https://your-secure-backend.example.com"
            setSingleLine(true)
            setText(prefs.getString("backend_url", ""))
            textSize = 14f
        }
        val provider = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("OpenAI ChatGPT + web search", "Google Gemini + Google Search"))
            setSelection(prefs.getInt("provider", 0).coerceIn(0, 1))
        }
        val question = EditText(this).apply {
            hint = "Ask about an app, APK, malware family, CVE, security technique, or current threat"
            minLines = 3; maxLines = 6; textSize = 15f
        }
        val keyStatus = TextView(this).apply {
            textSize = 12f
            text = if (ApiKeyVault.hasKey(this@MainActivity)) "OpenAI key: encrypted credential saved on this device." else "OpenAI key: not paired."
            setPadding(0, 6, 0, 6)
        }
        val info = TextView(this).apply {
            textSize = 12f
            text = "OpenAI pairing: your API key is encrypted using AES-256-GCM. The encryption key is held in Android Keystore and is not stored with the ciphertext. When you ask a question, the key is sent directly to api.openai.com over HTTPS; it is not sent to TheUnkwn backend. Device compromise/root access can still expose a key while it is in use. API usage is billed separately by OpenAI. A ChatGPT subscription does not include API credits."
            setPadding(0, 8, 0, 8)
        }
        val saveKey = Button(this).apply {
            text = "Encrypt & save OpenAI API key"
            setOnClickListener {
                val value = apiKey.text.toString().trim()
                if (!value.startsWith("sk-") || value.length < 20) {
                    Toast.makeText(this@MainActivity, "Enter a valid-looking OpenAI API key.", Toast.LENGTH_LONG).show()
                } else try {
                    ApiKeyVault.save(this@MainActivity, value)
                    apiKey.text.clear()
                    keyStatus.text = "OpenAI key: encrypted credential saved on this device."
                    Toast.makeText(this@MainActivity, "API key encrypted and saved.", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "Could not encrypt key: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
        val removeKey = Button(this).apply {
            text = "Remove saved OpenAI API key"
            setOnClickListener {
                ApiKeyVault.clear(this@MainActivity)
                keyStatus.text = "OpenAI key: not paired."
                Toast.makeText(this@MainActivity, "Saved API key removed.", Toast.LENGTH_SHORT).show()
            }
        }
        val saveBackend = Button(this).apply {
            text = "Save backend address"
            setOnClickListener {
                val value = endpoint.text.toString().trim().trimEnd('/')
                if (!value.startsWith("https://")) Toast.makeText(this@MainActivity, "Use a valid HTTPS backend URL.", Toast.LENGTH_LONG).show()
                else { prefs.edit().putString("backend_url", value).apply(); Toast.makeText(this@MainActivity, "Backend address saved.", Toast.LENGTH_SHORT).show() }
            }
        }
        box.addView(TextView(this).apply { text = "Connection method"; textSize = 13f })
        box.addView(mode)
        box.addView(TextView(this).apply { text = "OpenAI API key"; textSize = 13f; setPadding(0, 8, 0, 0) })
        box.addView(apiKey); box.addView(saveKey); box.addView(keyStatus); box.addView(removeKey)
        box.addView(TextView(this).apply { text = "Secure backend URL (optional alternative)"; textSize = 13f; setPadding(0, 10, 0, 0) })
        box.addView(endpoint); box.addView(saveBackend)
        box.addView(TextView(this).apply { text = "Backend AI provider"; textSize = 13f; setPadding(0, 8, 0, 0) })
        box.addView(provider); box.addView(question); box.addView(info)
        AlertDialog.Builder(this).setTitle("Ninjuku — AI Provider & API Pairing")
            .setView(ScrollView(this).apply { addView(box) }).setNegativeButton("Close", null)
            .setPositiveButton("Ask AI") { _, _ ->
                val prompt = question.text.toString().trim()
                if (prompt.isBlank()) { Toast.makeText(this, "Enter a research question.", Toast.LENGTH_LONG).show(); return@setPositiveButton }
                val selectedMode = mode.selectedItemPosition
                prefs.edit().putInt("ai_mode", selectedMode).putInt("provider", provider.selectedItemPosition).apply()
                saveResearchQuestion(prompt)
                if (selectedMode == 0) {
                    val key = ApiKeyVault.load(this)
                    if (key.isNullOrBlank()) { Toast.makeText(this, "Pair an OpenAI API key first.", Toast.LENGTH_LONG).show(); return@setPositiveButton }
                    requestOpenAiWithUserKey(key, prompt)
                } else {
                    val url = endpoint.text.toString().trim().trimEnd('/')
                    if (!url.startsWith("https://")) { Toast.makeText(this, "Save a valid HTTPS backend address first.", Toast.LENGTH_LONG).show(); return@setPositiveButton }
                    prefs.edit().putString("backend_url", url).apply()
                    requestIntegratedAi(url, if (provider.selectedItemPosition == 0) "openai" else "gemini", prompt)
                }
            }.show()
    }

    private fun requestOpenAiWithUserKey(apiKey: String, prompt: String) {
        if (!startUse("ai")) return
        val progress = ProgressBar(this).apply { isIndeterminate = true }
        val dialog = AlertDialog.Builder(this).setTitle("Researching with your OpenAI key…").setView(progress).setCancelable(false).create()
        dialog.show()
        executor.execute {
            var answer = ""; val citations = JSONArray(); var error: String? = null
            var connection: HttpURLConnection? = null
            try {
                connection = (URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 20000; readTimeout = 120000; doOutput = true
                    setRequestProperty("Authorization", "Bearer $apiKey")
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                }
                val payload = JSONObject().put("model", "gpt-5-mini")
                    .put("tools", JSONArray().put(JSONObject().put("type", "web_search")))
                    .put("input", "You are TheUnkwn security research assistant. Prioritize vendor advisories, CISA and CVE/NVD sources. Distinguish facts from hypotheses, explain uncertainty, and cite sources. Question: $prompt")
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val status = connection.responseCode
                val body = (if (status in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                val json = JSONObject(body.ifBlank { "{}" })
                if (status !in 200..299) throw IllegalStateException(json.optJSONObject("error")?.optString("message") ?: "OpenAI request failed (HTTP $status). Check API billing, key permissions and model access.")
                answer = json.optString("output_text", "")
                val output = json.optJSONArray("output") ?: JSONArray(); val seen = mutableSetOf<String>()
                for (i in 0 until output.length()) {
                    val item = output.optJSONObject(i) ?: continue
                    val content = item.optJSONArray("content") ?: continue
                    for (j in 0 until content.length()) {
                        val part = content.optJSONObject(j) ?: continue
                        if (part.optString("type") == "output_text" && answer.isBlank()) answer = part.optString("text")
                        val annotations = part.optJSONArray("annotations") ?: continue
                        for (k in 0 until annotations.length()) {
                            val a = annotations.optJSONObject(k) ?: continue
                            val url = a.optString("url", "")
                            if (url.startsWith("https://") && seen.add(url)) citations.put(JSONObject().put("title", a.optString("title", url)).put("url", url))
                        }
                    }
                }
                if (answer.isBlank()) throw IllegalStateException("No text answer returned.")
            } catch (e: Exception) { error = e.message ?: "OpenAI request failed." }
            finally { connection?.disconnect() }
            runOnUiThread {
                dialog.dismiss()
                finishUse("ai", error == null)
                if (error != null) AlertDialog.Builder(this).setTitle("OpenAI research unavailable").setMessage(error).setPositiveButton("OK", null).show()
                else showAiAnswer("openai", answer, citations)
            }
        }
    }

    private fun saveResearchQuestion(prompt: String) {
        val prefs = getSharedPreferences("theunkwn_learning", MODE_PRIVATE)
        val old = prefs.getStringSet("research_notes", emptySet())?.toMutableSet() ?: mutableSetOf()
        old.add("${timestamp()} | $prompt")
        prefs.edit().putStringSet("research_notes", old).apply()
    }

    private fun showNinjukuGateway() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 12, 24, 12) }
        val token = EditText(this).apply { hint = "Private test access token"; inputType = 129 }
        val question = EditText(this).apply { hint = "Describe the security concern (no private files or secrets)"; minLines = 3 }
        box.addView(token); box.addView(question)
        AlertDialog.Builder(this).setTitle("Ninjuku online — private debug test")
            .setMessage("Your typed question is sent to Cloudflare and OpenAI. No files are uploaded. The access token is not saved.")
            .setView(box).setNegativeButton("Cancel", null).setPositiveButton("Send") { _, _ ->
                val key = token.text.toString().trim(); val prompt = question.text.toString().trim(); token.text.clear()
                if (key.isBlank() || prompt.isBlank() || !startUse("ai")) return@setPositiveButton
                val dialog = AlertDialog.Builder(this).setMessage("Ninjuku is checking your question…").setCancelable(false).create(); dialog.show()
                executor.execute {
                    var result = "Connection failed. Check access and try again."; var success = false
                    var conn: HttpURLConnection? = null
                    try {
                        conn = (URL(getString(R.string.ninjuku_gateway_url)).also { require(it.protocol == "https") }.openConnection() as HttpURLConnection).apply {
                            requestMethod = "POST"; instanceFollowRedirects = false; connectTimeout = 15000; readTimeout = 120000; doOutput = true
                            setRequestProperty("Authorization", "Bearer $key"); setRequestProperty("Content-Type", "application/json")
                        }
                        conn.outputStream.use { it.write(JSONObject().put("message", prompt.take(12000)).toString().toByteArray(Charsets.UTF_8)) }
                        val status = conn.responseCode
                        if (status in 200..299) {
                            val data = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                            success = data.optBoolean("success")
                            if (success) result = "Ninjuku:\n${data.optString("ninjuku", "Unavailable")}\n\nOpenAI:\n${data.optString("openai", "Unavailable")}\n\nAdvice only. Verify findings before taking action."
                        } else {
                            result = when (status) {
                                401 -> "Access token invalid or expired."
                                429 -> "Too many requests. Wait a minute and retry."
                                502, 503 -> "Ninjuku service temporarily unavailable."
                                else -> "Connection failed (HTTP $status)."
                            }
                        }
                    } catch (_: Exception) { } finally { conn?.disconnect() }
                    runOnUiThread { dialog.dismiss(); finishUse("ai", success); if (!isFinishing && !isDestroyed) showAiAnswer("ninjuku", result, JSONArray()) }
                }
            }.show()
    }

    private fun requestIntegratedAi(baseUrl: String, provider: String, prompt: String) {
        if (!startUse("ai")) return
        val progress = ProgressBar(this).apply { isIndeterminate = true }
        val dialog = AlertDialog.Builder(this).setTitle("Researching with ${if (provider == "openai") "ChatGPT" else "Gemini"}…")
            .setView(progress).setCancelable(false).create()
        dialog.show()
        executor.execute {
            var answer = ""
            var sources = JSONArray()
            var error: String? = null
            var connection: HttpURLConnection? = null
            try {
                connection = (URL("$baseUrl/api/chat").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 120000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                }
                val payload = JSONObject().put("provider", provider).put("message", prompt)
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val status = connection.responseCode
                val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                val json = JSONObject(body.ifBlank { "{}" })
                if (status !in 200..299) throw IllegalStateException(json.optString("error", "Backend request failed (HTTP $status)."))
                answer = json.optString("answer", "")
                if (answer.isBlank()) throw IllegalStateException("No answer returned.")
                sources = json.optJSONArray("citations") ?: JSONArray()
            } catch (e: Exception) {
                error = e.message ?: "Could not connect to the AI backend."
            } finally { connection?.disconnect() }
            runOnUiThread {
                dialog.dismiss()
                finishUse("ai", error == null)
                if (error != null) {
                    AlertDialog.Builder(this).setTitle("AI research unavailable")
                        .setMessage("$error\n\nCheck the HTTPS backend address, server deployment, and API-key configuration.")
                        .setPositiveButton("OK", null).show()
                } else showAiAnswer(provider, answer, sources)
            }
        }
    }

    private fun showAiAnswer(provider: String, answer: String, citations: JSONArray) {
        val content = StringBuilder(answer.trim())
        if (citations.length() > 0) {
            content.append("\n\nSOURCES\n")
            for (i in 0 until citations.length()) {
                val item = citations.optJSONObject(i) ?: continue
                val title = item.optString("title", item.optString("url", "Source ${i + 1}"))
                val url = item.optString("url", "")
                if (url.startsWith("https://") || url.startsWith("http://")) content.append("\n${i + 1}. $title\n$url\n")
            }
        }
        val view = TextView(this).apply {
            text = content.toString()
            textSize = 14f
            setTextIsSelectable(true)
            android.text.util.Linkify.addLinks(this, android.text.util.Linkify.WEB_URLS)
            setPadding(28, 18, 28, 18)
        }
        AlertDialog.Builder(this).setTitle("${if (provider == "ninjuku") "Ninjuku dual AI" else if (provider == "openai") "ChatGPT" else "Gemini"} research result")
            .setView(ScrollView(this).apply { addView(view) })
            .setPositiveButton("Done", null).show()
    }

    private fun initializeBilling() {
        billingClient = BillingClient.newBuilder(this)
            .setListener(PurchasesUpdatedListener { result, purchases ->
                if (result.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
                    purchases.forEach { purchase ->
                        when (purchase.purchaseState) {
                            Purchase.PurchaseState.PURCHASED -> verifyPlayPurchase(purchase)
                            Purchase.PurchaseState.PENDING -> runOnUiThread { Toast.makeText(this, "Purchase pending. Premium unlocks only after Google Play confirms payment.", Toast.LENGTH_LONG).show() }
                            else -> Unit
                        }
                    }
                } else if (result.responseCode != BillingClient.BillingResponseCode.USER_CANCELED) {
                    runOnUiThread { Toast.makeText(this, "Google Play billing: ${result.debugMessage}", Toast.LENGTH_LONG).show() }
                }
            })
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .enableAutoServiceReconnection()
            .build()
        billingClient?.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) restorePlayPurchases()
            }
            override fun onBillingServiceDisconnected() { }
        })
    }

    private fun showSubscriptionPage() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 12, 24, 8) }
        box.addView(TextView(this).apply {
            text = "FREE — 20 completed scans or AI requests combined per local day; reports and settings are unlimited.\n\nPREMIUM MONTHLY — Integrated AI web research with source links.\n\nPREMIUM YEARLY — The same Premium AI research access with annual billing.\n\nGoogle Play displays the localized price, billing period and any trial/offer before you confirm. Subscriptions renew automatically unless cancelled in Google Play. Manage or cancel in Play Store → Payments & subscriptions. AI API usage through a personal OpenAI key is billed separately by OpenAI."
            textSize = 14f
        })
        val monthly = Button(this).apply { text = "Subscribe — Monthly Premium"; setOnClickListener { launchSubscription(monthlyProductId) } }
        val yearly = Button(this).apply { text = "Subscribe — Yearly Premium"; setOnClickListener { launchSubscription(yearlyProductId) } }
        val restore = Button(this).apply { text = "Restore purchases"; setOnClickListener { restorePlayPurchases() } }
        val manage = Button(this).apply { text = "Manage subscriptions in Google Play"; setOnClickListener {
            val uri = Uri.parse("https://play.google.com/store/account/subscriptions?package=$packageName")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } }
        box.addView(monthly); box.addView(yearly); loadPrice(monthlyProductId, monthly); loadPrice(yearlyProductId, yearly); box.addView(restore); box.addView(manage)
        val status = hasPremiumEntitlement()
        box.addView(TextView(this).apply { text = if (status) "Premium entitlement: verified until ${java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(getSharedPreferences("theunkwn_subscription", MODE_PRIVATE).getLong("expires_at", 0L)))}." else "Premium entitlement: Free plan. 20 combined completed uses daily. API provider charges may apply."; textSize = 12f; setPadding(0, 12, 0, 0) })
        AlertDialog.Builder(this).setTitle("TheUnkwn Plans").setView(ScrollView(this).apply { addView(box) }).setPositiveButton("Done", null).show()
    }

    private fun loadPrice(id: String, button: Button) {
        button.isEnabled = false
        button.text = "Google Play price unavailable"
        val client = billingClient ?: return
        if (!client.isReady) return
        val params = QueryProductDetailsParams.newBuilder().setProductList(listOf(QueryProductDetailsParams.Product.newBuilder().setProductId(id).setProductType(BillingClient.ProductType.SUBS).build())).build()
        client.queryProductDetailsAsync(params) { result, data ->
            val offer = data.productDetailsList.firstOrNull()?.subscriptionOfferDetails?.firstOrNull { it.offerId == null }
            val price = offer?.pricingPhases?.pricingPhaseList?.lastOrNull()?.formattedPrice
            runOnUiThread { if (result.responseCode == BillingClient.BillingResponseCode.OK && price != null) { button.text = "$price / ${if (id == monthlyProductId) "month" else "year"}"; button.isEnabled = true } }
        }
    }
    private fun showTestAd() {
        if (hasPremiumEntitlement()) return
        val consent = com.google.android.ump.UserMessagingPlatform.getConsentInformation(this)
        consent.requestConsentInfoUpdate(this, com.google.android.ump.ConsentRequestParameters.Builder().build(), {
            com.google.android.ump.UserMessagingPlatform.loadAndShowConsentFormIfRequired(this) { _ ->
                if (consent.canRequestAds() && !hasPremiumEntitlement()) {
                    com.google.android.gms.ads.MobileAds.initialize(this) {
                        runOnUiThread {
                            val ad = com.google.android.gms.ads.AdView(this)
                            ad.setAdSize(com.google.android.gms.ads.AdSize.BANNER)
                            ad.adUnitId = getString(R.string.admob_banner_id)
                            val dialog = AlertDialog.Builder(this).setTitle("Advertisement • test only").setView(ad).setPositiveButton("Close", null).create()
                            dialog.setOnDismissListener { ad.destroy() }; dialog.show()
                            ad.loadAd(com.google.android.gms.ads.AdRequest.Builder().build())
                        }
                    }
                }
            }
        }, { Toast.makeText(this, "Ad consent unavailable", Toast.LENGTH_SHORT).show() })
    }
    private fun launchSubscription(productId: String) {
        val client = billingClient
        if (client == null || !client.isReady) { Toast.makeText(this, "Google Play billing is connecting. Try again shortly.", Toast.LENGTH_LONG).show(); return }
        val params = QueryProductDetailsParams.newBuilder().setProductList(listOf(
            QueryProductDetailsParams.Product.newBuilder().setProductId(productId).setProductType(BillingClient.ProductType.SUBS).build()
        )).build()
        client.queryProductDetailsAsync(params) { result, queryResult ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK) {
                runOnUiThread { Toast.makeText(this, "Could not load subscription: ${result.debugMessage}", Toast.LENGTH_LONG).show() }; return@queryProductDetailsAsync
            }
            val details = queryResult.productDetailsList.firstOrNull()
            val offer = details?.subscriptionOfferDetails?.firstOrNull { it.offerId == null }
            if (details == null || offer == null) {
                runOnUiThread { Toast.makeText(this, "Subscription not found. Create product '$productId' and an active base plan in Play Console.", Toast.LENGTH_LONG).show() }; return@queryProductDetailsAsync
            }
            val productDetails: ProductDetails = details
            val productDetailsParams =
                BillingFlowParams.ProductDetailsParams.newBuilder()
                    .setProductDetails(productDetails)
                    .setOfferToken(offer.offerToken)
                    .build()
            runOnUiThread {
                val billingFlowParams =
                    BillingFlowParams.newBuilder()
                        .setProductDetailsParamsList(listOf(productDetailsParams))
                        .build()
                val launch = client.launchBillingFlow(this, billingFlowParams)
                if (launch.responseCode != BillingClient.BillingResponseCode.OK) Toast.makeText(this, "Purchase could not start: ${launch.debugMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun restorePlayPurchases() {
        val client = billingClient ?: return
        if (!client.isReady) return
        val params = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()
        client.queryPurchasesAsync(params) { result, purchases ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                val owned = purchases.filter { it.purchaseState == Purchase.PurchaseState.PURCHASED &&
                    it.products.any { product -> product == monthlyProductId || product == yearlyProductId } }
                if (owned.isEmpty()) {
                    getSharedPreferences("theunkwn_subscription", MODE_PRIVATE).edit()
                        .putBoolean("premium_verified", false).putLong("expires_at", 0L).apply()
                } else owned.forEach { verifyPlayPurchase(it) }
            }
        }
    }

    private fun hasPremiumEntitlement(): Boolean {
        val prefs = getSharedPreferences("theunkwn_subscription", MODE_PRIVATE)
        return prefs.getBoolean("premium_verified", false) &&
            System.currentTimeMillis() < prefs.getLong("expires_at", 0L)
    }

    private fun verifyPlayPurchase(purchase: Purchase) {
        val backend = getSharedPreferences("theunkwn_ai", MODE_PRIVATE).getString("backend_url", "")?.trimEnd('/') ?: ""
        if (!backend.startsWith("https://")) {
            runOnUiThread { Toast.makeText(this, "Purchase received. Configure your secure backend to verify and activate Premium.", Toast.LENGTH_LONG).show() }
            return
        }
        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL("$backend/api/play/verify").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 15000; readTimeout = 30000; doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val payload = JSONObject().put("packageName", packageName).put("productId", purchase.products.firstOrNull() ?: "")
                    .put("purchaseToken", purchase.purchaseToken)
                connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val status = connection.responseCode
                val body = (if (status in 200..299) connection.inputStream else connection.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                val verification = JSONObject(body.ifBlank { "{}" })
                val active = status in 200..299 && verification.optBoolean("active", false)
                val expiry = try { java.time.Instant.parse(verification.optString("expiryTime", "")).toEpochMilli() } catch (_: Exception) { 0L }
                getSharedPreferences("theunkwn_subscription", MODE_PRIVATE).edit()
                    .putBoolean("premium_verified", active && expiry > System.currentTimeMillis())
                    .putLong("expires_at", expiry)
                    .putString("product_id", purchase.products.firstOrNull()).apply()
                runOnUiThread { Toast.makeText(this, if (active && expiry > System.currentTimeMillis()) "Premium subscription verified and activated." else "Subscription is not active. Premium remains locked.", Toast.LENGTH_LONG).show() }
            } catch (_: Exception) {
                runOnUiThread { Toast.makeText(this, "Could not verify purchase. Premium remains locked until verification succeeds.", Toast.LENGTH_LONG).show() }
            } finally { connection?.disconnect() }
        }
    }

    private fun exportReport() {
        if (lines.isEmpty()) {
            Toast.makeText(this, "Run a scan first.", Toast.LENGTH_SHORT).show()
            return
        }
        pendingReport = buildString {
            append("THEUNKWN SECURITY AUDIT REPORT\nCreated: ${timestamp()}\n\n")
            synchronized(lines) { append(lines.joinToString("\n")) }
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/plain"
            putExtra(Intent.EXTRA_TITLE, "theunkwn-security-report.txt")
        }
        startActivityForResult(intent, createReport)
    }

    private fun writeReport(uri: Uri) {
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingReport) }
            Toast.makeText(this, "Report saved.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Could not save report: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun timestamp() = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
    private fun humanBytes(value: Long): String = when {
        value >= 1_073_741_824L -> "%.2f GB".format(Locale.US, value / 1_073_741_824.0)
        value >= 1_048_576L -> "%.2f MB".format(Locale.US, value / 1_048_576.0)
        value >= 1024L -> "%.2f KB".format(Locale.US, value / 1024.0)
        else -> "$value bytes"
    }

    override fun onDestroy() {
        stopScan()
        clock.removeCallbacks(finishLaunch)
        clock.removeCallbacks(tick)
        super.onDestroy()
        billingClient?.endConnection()
        executor.shutdown()
    }
}
