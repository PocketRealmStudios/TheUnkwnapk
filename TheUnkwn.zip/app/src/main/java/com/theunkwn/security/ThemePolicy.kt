package com.theunkwn.security

internal object ThemePolicy {
    fun allowsCustom(page: String): Boolean = page in setOf("Home", "Scanner", "Watchdog", "Reports", "Settings", "Premium & Ads")
}
