package com.theunkwn.security
import kotlin.math.exp
object NinjukuPresence {
    private val names = arrayOf("android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.INTERNET", "android.permission.ACCESS_COARSE_LOCATION", "android.permission.ACCESS_FINE_LOCATION", "android.permission.SEND_SMS", "android.permission.VIBRATE", "android.permission.CHANGE_WIFI_STATE")
    private val weights = doubleArrayOf(0.7286547125282148, 2.0298467850226043, -0.6008477585203305, 0.9724029012659107, -0.7605334335647419, -1.189685491572144, -0.13852551657423703, 2.4544183068438166)
    fun score(permissions: Set<String>): Double {
        var z = -0.3310357208879208
        for (i in names.indices) if (names[i] in permissions) z += weights[i]
        return 1.0 / (1.0 + exp(-z))
    }
}
