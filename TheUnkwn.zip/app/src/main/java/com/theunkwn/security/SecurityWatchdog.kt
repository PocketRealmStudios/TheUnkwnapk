package com.theunkwn.security

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.io.File
import java.security.MessageDigest
import java.util.Locale
import java.util.zip.ZipFile
import kotlin.math.ln

/** Local, explainable APK triage. This is heuristic analysis, not a trained malware classifier. */
object AdaptiveMalwareAssistant {
    data class Result(val score: Int, val details: List<String>, val sha256: String)

    fun inspect(apk: File): Result {
        val details = mutableListOf<String>()
        if (!apk.isFile || apk.length() <= 0L || apk.length() > 150L * 1024L * 1024L)
            return Result(0, listOf("APK unavailable or outside the 150 MB analysis limit"), "")
        val digest = try {
            MessageDigest.getInstance("SHA-256").let { md -> apk.inputStream().use { input -> val b = ByteArray(65536); while (true) { val n = input.read(b); if (n < 0) break; md.update(b, 0, n) } }; md.digest() }.joinToString("") { "%02x".format(it) }
        } catch (_: Exception) { "" }
        var score = 0
        try {
            ZipFile(apk).use { zip ->
                val entries = zip.entries().asSequence().toList()
                val dexEntries = entries.filter { it.name.matches(Regex("classes(\\d+)?\\.dex")) }.take(4)
                var dexEntropy = 0.0
                var dexCount = 0
                var dexText = ""
                dexEntries.forEach { entry ->
                    if (entry.size in 1..(16L * 1024L * 1024L)) {
                        val bytes = zip.getInputStream(entry).use { it.readBytes() }
                        dexEntropy = maxOf(dexEntropy, entropy(bytes))
                        dexText += bytes.toString(Charsets.ISO_8859_1).lowercase(Locale.ROOT).take(2_000_000)
                        dexCount++
                    }
                }
                val loaderMarkers = listOf("dalvik/system/dexclassloader", "dalvik/system/inmemorydexclassloader", "java/lang/classloader", "loadclass")
                val loaderHits = loaderMarkers.count { dexText.contains(it) }
                if (loaderHits >= 2) { score += 2; details.add("Multiple dynamic-code-loading indicators") }
                val decodeMarkers = listOf("javax/crypto/cipher", "base64", "deflatestream", "cipher.getinstance", "xor")
                val decodeHits = decodeMarkers.count { dexText.contains(it) }
                if (decodeHits >= 3) { score += 2; details.add("Several encryption/decoding indicators in DEX") }
                if (dexCount > 0 && dexEntropy >= 7.25) { score += 2; details.add("High-entropy DEX payload (may indicate packing or encryption)") }
                val nativeLibs = entries.count { it.name.startsWith("lib/") && it.name.endsWith(".so") }
                if (nativeLibs >= 4 && loaderHits > 0) { score += 1; details.add("Native libraries combined with dynamic loading") }
                val suspiciousAssets = entries.count { e ->
                    val n = e.name.lowercase(Locale.ROOT)
                    n.startsWith("assets/") && (n.endsWith(".bin") || n.endsWith(".dat") || n.endsWith(".enc") || n.endsWith(".dex"))
                }
                val execution = listOf("java/lang/runtime", "java/lang/processbuilder", "dalvik/system/inmemorydexclassloader").count { dexText.contains(it) }
                val collection = listOf("android/provider/contactscontract", "android/media/mediarecorder", "android/accessibilityservice/accessibilityservice").count { dexText.contains(it) }
                val network = listOf("java/net/httpurlconnection", "okhttp3/", "java/net/socket").any { dexText.contains(it) }
                if (execution >= 2 && loaderHits >= 2 && decodeHits >= 2) { score += 2; details.add("Combined dynamic loading, execution and decoding indicators") }
                if (collection >= 2 && network && loaderHits >= 2) { score += 2; details.add("Combined sensitive-data, networking and dynamic loading indicators; actual activity not verified") }
                if (suspiciousAssets >= 3 && decodeHits >= 2) { score += 1; details.add("Multiple opaque asset payloads with decoding indicators") }
            }
        } catch (_: Exception) { details.add("APK structure could not be fully inspected") }
        if (details.isEmpty()) details.add("No strong polymorphic/packing indicators found by the local heuristic rules")
        return Result(score, details, digest)
    }

    private fun entropy(bytes: ByteArray): Double {
        if (bytes.isEmpty()) return 0.0
        val counts = IntArray(256)
        bytes.forEach { counts[it.toInt() and 0xff]++ }
        var h = 0.0
        counts.filter { it > 0 }.forEach { count ->
            val p = count.toDouble() / bytes.size
            h -= p * (ln(p) / ln(2.0))
        }
        return h
    }
}

object WatchdogNotifications {
    const val CHANNEL_ID = "theunkwn_security_watchdog"
    fun show(context: Context, title: String, message: String, id: Int) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26 && manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Security Watchdog", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Alerts for newly installed apps and suspicious APK indicators"
                lockscreenVisibility = android.app.Notification.VISIBILITY_PRIVATE
            })
        }
        val open = PendingIntent.getActivity(context, id, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle(title).setContentText(message).setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setAutoCancel(true).setContentIntent(open).build()
        try { NotificationManagerCompat.from(context).notify(id, notification) } catch (_: SecurityException) { }
    }
}

class SecurityWatchdogReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    private fun getApplicationInfoLegacy(pm: PackageManager, pkg: String) = pm.getApplicationInfo(pkg, 0)
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_PACKAGE_ADDED && intent.action != Intent.ACTION_PACKAGE_REPLACED) return
        if (intent.action == Intent.ACTION_PACKAGE_ADDED && intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
        val prefs = context.getSharedPreferences("security_watchdog", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", true)) return
        val pkg = intent.data?.schemeSpecificPart ?: return
        val pm = context.packageManager
        val app = try {
            if (Build.VERSION.SDK_INT >= 33) pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0L))
            else getApplicationInfoLegacy(pm, pkg)
        } catch (_: Exception) { return }
        val label = try { pm.getApplicationLabel(app).toString() } catch (_: Exception) { pkg }
        var installer: String? = null
        var initiating: String? = null
        var originating: String? = null
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val src = pm.getInstallSourceInfo(pkg)
                installer = src.installingPackageName
                initiating = src.initiatingPackageName
                originating = src.originatingPackageName
            } catch (_: Exception) { }
        } else {
            @Suppress("DEPRECATION")
            try { installer = pm.getInstallerPackageName(pkg) } catch (_: Exception) { }
        }
        val fromPlay = installer == "com.android.vending" || initiating == "com.android.vending"
        val source = listOfNotNull(originating, initiating, installer).distinct().joinToString(" → ").ifBlank { "not reported by Android" }
        val apk = File(app.sourceDir ?: "")
        val analysis = AdaptiveMalwareAssistant.inspect(apk)
        val previousHash = prefs.getString("hash:$pkg", null)
        prefs.edit().putString("hash:$pkg", analysis.sha256).apply()
        val changedBinary = previousHash != null && analysis.sha256.isNotBlank() && previousHash != analysis.sha256
        val riskText = when {
            analysis.score >= 5 -> "Review indicators (${analysis.score}): ${analysis.details.joinToString("; ")}"
            analysis.score >= 3 -> "Review recommended (${analysis.score}): ${analysis.details.joinToString("; ")}"
            else -> "No strong polymorphic indicators found; this is not a clean bill of health."
        }
        val originText = if (fromPlay) "Installed through Google Play." else "Outside Google Play or source unverified."
        val eventLabel = if (intent.action == Intent.ACTION_PACKAGE_REPLACED) "app updated" else "new app detected"
        val message = "$originText Source: $source. $riskText" + if (changedBinary) " APK binary differs from the last recorded version." else ""
        if (true) {
            WatchdogNotifications.show(context, "TheUnkwn: $eventLabel — $label", message, (pkg.hashCode() and 0x7fffffff))
        }
        prefs.edit().putString("last_event", "$label ($pkg): $message").apply()
    }
}
