import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.theunkwn.security"
    compileSdk = 35

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    defaultConfig {
        applicationId = "com.theunkwn.security"
        minSdk = 26
        targetSdk = 35
        manifestPlaceholders["admobAppId"] = providers.gradleProperty("ADMOB_APP_ID").orElse("ca-app-pub-3940256099942544~3347511713").get()
        resValue("string", "ninjuku_gateway_url", providers.gradleProperty("NINJUKU_GATEWAY_URL").orElse("https://theunkwn-auth.gtrev8921.workers.dev/analyze").get())
        resValue("string", "admob_banner_id", providers.gradleProperty("ADMOB_BANNER_ID").orElse("ca-app-pub-3940256099942544/6300978111").get())
        resValue("string", "admob_native_id", providers.gradleProperty("ADMOB_NATIVE_ID").orElse("ca-app-pub-3940256099942544/2247696110").get())
        resValue("string", "admob_rewarded_id", providers.gradleProperty("ADMOB_REWARDED_ID").orElse("ca-app-pub-3940256099942544/5224354917").get())
        versionCode = 21
        versionName = "13.6-repair-preview"
    }
    signingConfigs {
        create("release") {
            val keystorePath = System.getenv("ANDROID_KEYSTORE_PATH")
            if (!keystorePath.isNullOrBlank()) storeFile = file(keystorePath)
            storePassword = System.getenv("ANDROID_KEYSTORE_PASSWORD")
            keyAlias = System.getenv("ANDROID_KEY_ALIAS")
            keyPassword = System.getenv("ANDROID_KEY_PASSWORD")
        }
    }
    buildTypes {
        getByName("release") {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }
}
kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-ads:24.9.0")
    implementation("com.google.android.ump:user-messaging-platform:3.2.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("com.android.billingclient:billing:9.1.0")
}
