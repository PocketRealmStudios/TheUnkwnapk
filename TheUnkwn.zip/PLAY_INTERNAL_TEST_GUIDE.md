# TheUnkwn — Google Play internal subscription test guide

Use this checklist after building the signed `app-release.aab`.

1. In Play Console, create an **Internal testing** track under **Test and release → Testing**.
2. In the track's **Testers** tab, create an email list and add the Google account on your Android phone. Save and copy the opt-in link.
3. Separately add that same account under **Settings → License testing**. Internal-test enrollment and license testing are separate configurations.
4. Create and activate subscriptions with exact IDs `theunkwn_premium_monthly` (monthly base plan) and `theunkwn_premium_yearly` (yearly base plan). Configure prices and countries.
5. Upload the signed AAB to the internal track and roll out the release. Wait for Play processing.
6. On the phone, use the same Google account in Play Store, open the opt-in link, accept, and install from Google Play.
7. Open TheUnkwn → Premium Subscriptions → Monthly or Yearly. On the Google Play purchase sheet, choose **Test card, always approves**. The sheet should identify this as a test purchase. Proper license tester purchases use test instruments rather than charging a normal payment method.
8. Confirm the backend verifies the purchase and Premium unlocks. Use Restore purchases and restart the app to test restoration.
9. Repeat with **Test card, always declines** and confirm Premium stays locked. Test cancellation, renewal, pending payment and restore. Play Billing Lab can accelerate subscription lifecycle tests.

**Do not proceed if Google Play shows a normal payment method or an ordinary price without a test-purchase indication.** Check that the purchasing account is listed under License testing.

Google's official instructions:
- [Internal testing tracks](https://support.google.com/googleplay/android-developer/answer/9845334)
- [License testing and test purchases](https://support.google.com/googleplay/android-developer/answer/6062777)
- [Test Google Play Billing](https://developer.android.com/google/play/billing/test)

## Before publishing publicly
- Deploy the HTTPS backend and configure the Google Play Developer API service account.
- The current backend has basic rate limiting but no complete user authentication or Android app attestation. Add Firebase App Check plus user authentication or equivalent API-gateway protection before making the AI backend publicly accessible.
- Configure a private upload keystore and GitHub Actions secrets; never commit the keystore or credentials.
- Complete Play Console privacy policy, Data safety, permissions declarations, subscription disclosures and required policy review.
- Build and test the signed AAB. This repository ZIP is source, not a verified APK/AAB.
