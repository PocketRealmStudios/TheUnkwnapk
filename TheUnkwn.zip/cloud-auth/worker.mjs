export default {
  async fetch(request, env) {
    const reply = (status, data) => Response.json(data, {
      status, headers: { 'Cache-Control': 'no-store' }
    });
    let stage = 'route';
    try {
      const path = new URL(request.url).pathname;
      if (request.method === 'GET' && path === '/') {
        return reply(200, { success: true, status: 'Online' });
      }
      if (request.method !== 'POST' || path !== '/analyze') {
        return reply(404, { error: 'Not found' });
      }
      const auth = request.headers.get('Authorization') || '';
      const match = auth.match(/^Bearer ([A-Za-z0-9_-]{32,128})$/);
      if (!match) return reply(401, { error: 'Unauthorized' });
      stage = 'bindings';
      if (!env.USER_TOKENS || !env.UPSTREAM_SECRET ||
          !env.USER_RATE_LIMITER || !env.NINJUKU_SERVICE) {
        return reply(503, { error: 'Required binding missing' });
      }
      stage = 'token verification';
      const digest = await crypto.subtle.digest('SHA-256',
        new TextEncoder().encode(match[1]));
      const hash = Array.from(new Uint8Array(digest),
        b => b.toString(16).padStart(2, '0')).join('');
      const expiry = Number(await env.USER_TOKENS.get(hash));
      if (!Number.isFinite(expiry) || expiry <= Date.now()) {
        return reply(401, { error: 'Unauthorized' });
      }
      stage = 'rate limiter';
      const limit = await env.USER_RATE_LIMITER.limit({ key: hash });
      if (!limit.success) return reply(429, { error: 'Rate limit reached' });
      stage = 'request body';
      if (!request.body) return reply(400, { error: 'Missing body' });
      const reader = request.body.getReader();
      const chunks = [];
      let size = 0;
      while (true) {
        const part = await reader.read();
        if (part.done) break;
        size += part.value.byteLength;
        if (size > 48000) {
          await reader.cancel();
          return reply(413, { error: 'Request too large' });
        }
        chunks.push(part.value);
      }
      let data;
      try { data = JSON.parse(await new Blob(chunks).text()); }
      catch { return reply(400, { error: 'Invalid JSON' }); }
      if (!data || typeof data.message !== 'string' ||
          !data.message.trim() || data.message.length > 12000) {
        return reply(400, { error: 'Invalid message' });
      }
      stage = 'Ninjuku service';
      const upstream = await env.NINJUKU_SERVICE.fetch(new Request(
        'https://ninjukuai.gtrev8921.workers.dev/analyze', {
          method: 'POST',
          headers: {
            Authorization: 'Bearer ' + env.UPSTREAM_SECRET,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ message: data.message })
        }));
      stage = 'Ninjuku response';
      return new Response(await upstream.text(), {
        status: upstream.status,
        headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }
      });
    } catch (error) {
      console.error('Gateway failure', stage, error.name);
      return reply(502, { success: false, error: 'Gateway failure', stage });
    }
  }
};
