## GitHub Actions APK build

The repository name and Android application name remain **TheUnkwn**.

1. Create a GitHub repository named `TheUnkwn`.
2. Upload the contents of this project folder to the repository root (including the `.github` folder).
3. Push/commit to `main` or `master`, or manually run the workflow from the GitHub **Actions** tab.
4. Open the completed **Build TheUnkwn 10.0** workflow run.
5. Download the `theunkwn-v10-debug-apk` artifact to get the debug APK.

The debug build is intended for testing and sideloading. A Play Store release bundle requires configuring the release keystore and secrets described below.

# TheUnkwn — Android security, malware-indicator and privacy auditor

**Current project version: 10.0** · Minimum Android 8.0 (API 26) · Android 10 (API 29) supported

TheUnkwn combines an offline local signature/heuristic file checker with an installed-app privacy and stalkerware-risk audit. It is designed to help users find items that deserve closer review. It does not claim to be a certified antivirus product and cannot guarantee detection of all malware.

## Front-page guide

The app explains these limits and scan modes on its opening screen. Tap **SCAN ENTIRE PHONE** to begin. On Android 10, Android opens the Storage Access Framework folder picker; choose the shared-storage root (or the broadest folder Android lets you select). The app then runs the app inventory and scans that selected folder tree in the same scan session. On Android 11+, grant the special All files access permission and tap the scan button again for a broader shared-storage scan.

## What version 5.0 checks

### Local malware-indicator engine
- Checks accessible files up to 25 MiB each for the standard EICAR antivirus test signature. An EICAR match is a harmless antivirus test file, not live malware.
- Checks common script formats for a small set of download-and-execute and decode-and-execute patterns.
- Inspects accessible APK archives for sensitive manifest permission declarations, embedded script files, and selected high-risk API strings in a bounded number of DEX entries.
- Reports indicators and reasons; it never executes scanned files.
- Adds a user-confirmed quarantine flow for EICAR test-signature and suspicious download-and-execute script findings. It copies the selected file into TheUnkwn's private app storage, checks the copy, and only then removes the original. If copy or verification fails, the original is retained.
- Adds a restore function that copies quarantined files back to a folder chosen by the user. The private quarantine copy remains until manually cleared by uninstalling the app or using device app-data controls.

This is a small offline signature and heuristic engine, **not** a full antivirus engine. It has no cloud reputation service, no continuously refreshed threat database, no behavioral sandbox, and no guarantee of detecting new, packed, encrypted, or obfuscated malware. A clean result does not prove a file is safe. APK permission/API indicators can also occur in legitimate applications.

### Exposure Trail — app capability change tracking

The new Exposure Trail stores a device-local baseline of each visible app's declared sensitive permissions and visible special-access indicators (such as enabled accessibility services and active device-admin status). Later scans compare the current snapshot with that baseline and call out newly declared capabilities and packages that are no longer present. This helps answer a practical question that a one-time permission list cannot: **what changed since the last scan?** The baseline stays in app-private preferences and is not uploaded. It detects visible configuration changes, not actual message reading, data exfiltration, or all runtime behavior. Reinstalling or clearing TheUnkwn's app data resets the baseline.

## Stalkerware and app privacy review
- Inventories installed applications visible to Android, including packages without launcher icons where package visibility permits.
- Reviews declared permissions for SMS, contacts, call logs, phone state, microphone, camera, location, photos/video/audio, and broad storage access.
- Checks for services declaring Android's accessibility binding permission, currently enabled accessibility services, device-admin receivers, and active device-admin apps.
- Assigns an explainable elevated privacy-risk score when multiple sensitive capabilities are combined.
- Notes unknown installers, disabled apps, missing labels, and apps without launcher entries for manual review.

A high score is not proof of spying. Accessibility tools, password managers, parental-control tools, enterprise management software, and security products can legitimately use powerful permissions. Verify the app publisher and purpose before disabling or uninstalling anything.

## Android 10 compatibility (API 29)

Android 10 introduced scoped storage. TheUnkwn uses the Android Storage Access Framework folder picker on Android 10. Select the shared-storage root or another folder and grant read access. The app scans that selected folder and accessible descendants while also auditing the installed-app inventory. Android 10 may block particular subfolders, including protected app-data areas. If the device does not allow selecting the storage root, scan the largest folders Android permits, one at a time.

The app cannot access other apps' private sandboxes, private SMS/chat/email databases, protected system partitions, or every removable-storage location. Android does not provide an ordinary third-party app with permission to read other apps' private messages or email content. TheUnkwn therefore reviews app permissions and visible system configuration rather than opening private communications.

## Android 11 and later

The app can request Android's special **All files access** permission for broader shared-storage scanning. This is granted by the user in Android Settings and remains subject to platform restrictions. App inventory visibility can also be affected by device policy and Android package-visibility rules.

## Permissions and privacy

- `QUERY_ALL_PACKAGES`: broad installed-app inventory; subject to Android and app-distribution policy.
- `MANAGE_EXTERNAL_STORAGE`: optional special access on Android 11+ for broad shared-storage scans.
- `READ_EXTERNAL_STORAGE` (limited to API 32): legacy read permission.
- Android 10: user-selected folder read access through the Storage Access Framework.

The app requests internet access only for the optional integrated AI research feature. Local scan results remain on the device unless the user explicitly exports or shares them. AI questions typed into the research assistant are sent to the selected provider through the configured backend. Scanning itself is read-only. Files are moved only after the user presses Quarantine flagged files and confirms; the copy is verified before the original is removed. The restore action copies items back to a user-selected folder and retains the quarantine copy. Quarantine contents are app-private and are deleted if TheUnkwn is uninstalled, so restore important items before uninstalling.

## Differentiating feature and market comparison

Google Play listings for established Android security products already advertise overlapping capabilities such as app/file scans, permission insights, malware quarantine, AI or behavior-based detection, and privacy checks. TheUnkwn does not claim that no other antivirus can do any one of these things. Its differentiating design in this project is the **Exposure Trail**: a local, per-app baseline that highlights newly declared sensitive capabilities between scans, combined in the same report with stalkerware indicators and a user-controlled, reversible quarantine/restore workflow for supported file findings. This is a focused design distinction, not a claim of industry-first status or independently validated antivirus protection.

## Build a signed test APK

Use JDK 17 with the bundled, SHA-256-verified Gradle 8.9 distribution:

```bash
./build-with-bundled-gradle.sh assembleDebug
```

On Windows PowerShell, use `./build-with-bundled-gradle.ps1 assembleDebug`. The normal `./gradlew` wrapper also remains available and downloads the same Gradle 8.9 distribution with SHA-256 verification. The build helper delegates to the Gradle Wrapper, which downloads Gradle 8.9 from the official Gradle service and verifies its SHA-256 checksum. The Android Gradle Plugin signs the debug APK automatically. The included distribution is larger than GitHub’s 100 MB regular-file limit, so when committing the extracted project use Git LFS (`git lfs install` and `git lfs track "*.zip"`) and commit the generated `.gitattributes`; both GitHub Actions jobs check out LFS files. with the standard debug key. This APK is suitable for testing and sideloading, not Play Store distribution. A production release should be signed with your own private keystore. Never commit keystore files or passwords to source control.

## GitHub Actions

Push this project to a GitHub repository and run **Actions → Build TheUnkwn 10.0**. The workflow validates the official Wrapper JAR, verifies and uses the bundled Gradle 8.9 ZIP, then builds and uploads the `theunkwn-v10-debug-apk` artifact. The build must complete successfully before an APK can be considered produced.


## Version 6.0 — Security Watchdog and Adaptive Malware Assistant

### New install watchdog
- Android's `PACKAGE_ADDED` system broadcast triggers an event-driven check when a package is installed, including while TheUnkwn is not open (subject to Android/device restrictions). This is not a permanently running background scanner; Android does not permit ordinary apps to continuously inspect every other app.
- The watchdog reads Android's install-source metadata and identifies Google Play installs versus installs from another or unverified source. A non-Play/unverified install produces a high-priority notification. Android does not expose the identity of the human who tapped Install, so the app cannot prove that the phone owner personally initiated the download or block the install before it happens.
- Notifications are configured for lock-screen visibility, but the phone owner's Android lock-screen notification/privacy settings and notification permission control what is actually displayed. Android 13+ requires notification permission.
- Use the **Security Watchdog** switch on the home screen to pause or enable install monitoring.

### Polymorphic Malware AI Assistant (on-device heuristic triage)
- Performs local, explainable heuristic checks on newly installed APKs and during a full app scan: DEX entropy, dynamic-code-loading indicators, encryption/decoding markers, opaque embedded payloads, native-library combinations, and APK hash changes across versions.
- Reports a review score and the indicators that contributed to it. High entropy, obfuscation, dynamic loading, and encryption are also used by legitimate apps, so a score is not proof of malware.
- Despite the feature name, this is an explainable on-device heuristic assistant, not a trained machine-learning model. It does not guarantee detection of polymorphic malware and is not a substitute for Google Play Protect or a commercial endpoint security product. It does not upload APKs or scan other apps' private runtime memory.

### Android compatibility and limits
- Minimum Android 8 (API 26); Android 10+ install events are monitored using the package-added broadcast.
- The app cannot determine the identity of the person using the phone, intercept/approve another app's installation before Android installs it, or guarantee uninterrupted background execution on every vendor device.
- To receive alerts, allow TheUnkwn notifications. On Android 13+, grant notification permission when prompted. To show alert content on the lock screen, set Android lock-screen notification privacy to show content.
- The watchdog checks installed apps after installation. It does not monitor every download that never gets installed.


## Version 7.0 — Local learning notebook and feedback email

### On-device learning notebook
- The **Teach the local AI from scan feedback** action stores user-labelled examples: confirmed suspicious, likely false positive, or needs more investigation. Each entry can include an app/package/hash/indicator and notes.
- Examples remain in private app preferences on the device. The owner can include them in an email feedback report for review and potential incorporation into future detection-rule updates.
- This is a reviewed training-data collection workflow, **not an automatically retraining neural network**. User labels do not immediately alter detection scores or executable code.

### Email feedback and code-improvement reports
- **Email feedback / improvement report** prepares a message addressed to `gtrev8921@gmail.com` containing recent scan logs, app/Android version, local training labels, and saved research questions.
- Android opens the user's chosen email app with the message prefilled. The owner reviews and presses Send; TheUnkwn does not silently send mail.
- APKs, quarantined files, and private app data are not attached. Review the report before sending because scan logs may contain app/package names and file paths.

## Version 8.0 — Integrated ChatGPT and Gemini web research

### In-app AI research
- The **Integrated AI Research (ChatGPT + Gemini)** screen lets the user choose OpenAI ChatGPT with OpenAI web search or Google Gemini with Google Search grounding.
- The selected model's answer and available source URLs are returned to TheUnkwn and displayed inside the app. Research questions are saved in the local research notebook.
- The assistant is instructed to prioritize vendor advisories and CVE/NVD/CISA information, distinguish confirmed facts from hypotheses, and avoid treating heuristic indicators as proof of malware.
- The Android app sends only the question and selected provider to the backend. It does not automatically upload scan logs, APKs, quarantined files, or private app data.

### Secure backend and API configuration
- A Node.js backend is included in `ai-backend/`. It exposes `POST /api/chat` and calls the OpenAI Responses API with its `web_search` tool, or Gemini `generateContent` with `googleSearch` grounding. It normalizes answers and citations for the Android client.
- Set `OPENAI_API_KEY` and `GEMINI_API_KEY` as **server-side environment secrets**. Optional `OPENAI_MODEL` and `GEMINI_MODEL` variables override model defaults. Never place provider keys in Kotlin, Gradle files, GitHub source, or the APK.
- Deploy `ai-backend/` to an HTTPS Node.js host (for example, Google Cloud Run). Configure provider keys in that host's Secret Manager/environment settings. Test `GET /health`, then enter the deployed base URL in the app's AI Research screen and tap **Save backend address**.
- The included per-IP rate limiter is a basic safeguard, not full production authentication. Before public distribution, put the endpoint behind an app-attestation/authentication layer (such as Firebase App Check or an API gateway), enforce provider spending quotas, and monitor abuse. Do not treat an unlisted URL as a secret.
- API usage is billed by the providers and requires active API accounts, enabled billing/credits where applicable, and valid keys. The APK does not contain provider credentials. User questions are transmitted to the selected provider; do not submit passwords, private messages, or other secrets.
- AI output and cited pages are untrusted research material. TheUnkwn does not execute commands, download patches, modify files, or update its own detection rules based on AI output.

### Deploy backend (overview)
1. Deploy the `ai-backend` directory as a Node.js 20 service with HTTPS.
2. Add `OPENAI_API_KEY` and `GEMINI_API_KEY` as server secrets/environment variables. The service can run with only one provider configured, but the other provider will remain unavailable until its key is added.
3. Confirm `/health` reports the configured providers, then paste the service base URL into the Android app.
4. Secure the endpoint with App Check/API Gateway before sharing the app beyond personal testing. The simple built-in rate limiter is not a substitute for authentication or a billing cap.

## Build version 8.0

Run `./gradlew assembleDebug` from the project root, or use GitHub Actions → **Build TheUnkwn 8.0 APK**. The workflow artifact is named `theunkwn-v8-debug-signed-apk`. A successful workflow run is required before claiming the APK has been built.


## Version 9.0 — API key pairing and Google Play subscriptions

### Optional OpenAI API key pairing
- The AI Research page now offers a direct OpenAI connection using a user's own API key, or the existing secure backend option for OpenAI/Gemini.
- The OpenAI key is encrypted locally with AES-256-GCM. The encryption key is generated and retained by Android Keystore; only ciphertext is stored in private app preferences. App backup is disabled in the manifest.
- Direct requests go from the phone to `https://api.openai.com/v1/responses` over HTTPS with the `web_search` tool. The key is not sent to TheUnkwn's AI backend. A ChatGPT consumer subscription does not provide API credits; API billing is separate and belongs to the key owner.
- Users can remove the stored key from the pairing page. If Android Keystore data is invalidated or app data is cleared, the key may need to be entered again.
- Keystore encryption protects stored data at rest; it cannot guarantee protection on a rooted/compromised device or while the key is being used in memory/network requests. Never share an API key. Use provider spending limits and revoke a key if exposed.

### Google Play subscriptions
- Adds Google Play Billing Library 9.1.0 and subscription product IDs `theunkwn_premium_monthly` and `theunkwn_premium_yearly`.
- In Play Console, create a subscription for each exact product ID above and create/activate a monthly or yearly base plan. Configure the prices, countries, tax settings, and offers in Play Console; the app reads localized prices/eligible offers from Google Play.
- The Premium screen also includes restore purchases and a Google Play subscription-management link.
- Purchase tokens are sent to the HTTPS backend `/api/play/verify`. The backend uses a Google Play Developer API service account to verify the subscription state and expiry before returning an active entitlement. Premium must remain locked if verification is unavailable or fails.
- Backend environment secrets required for subscription verification:
  - `GOOGLE_PLAY_PACKAGE_NAME=com.theunkwn.security`
  - `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` = the complete service-account JSON credential as a protected server secret. Grant the service account the minimum required Play Console permissions and link the Google Play Developer API in Google Cloud.
- Configure `OPENAI_API_KEY`, `GEMINI_API_KEY`, and model variables on the backend as before. Do not commit provider keys or service-account JSON to GitHub.
- The backend currently verifies subscription purchases, but production launch still requires full end-to-end testing of purchase, acknowledgement, renewal, cancellation, grace-period, refund/revocation, and account/device restore flows. A cached on-device entitlement is not a substitute for periodic server-side entitlement refresh.

### Play Console setup checklist
1. Create the app in Play Console using package name `com.theunkwn.security`.
2. Create subscription product IDs `theunkwn_premium_monthly` and `theunkwn_premium_yearly` and configure their base plans/prices.
3. Set up the Google Play Developer API service account and add its JSON as a backend secret, not an app asset.
4. Deploy the backend with HTTPS and set `GOOGLE_PLAY_PACKAGE_NAME` and `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON`.
5. Set the deployed HTTPS backend URL in TheUnkwn AI Pairing page. The same endpoint is used for Play purchase verification.
6. Upload a signed AAB to an internal testing track, add license testers, and test purchases using Play's test payment methods before production.
7. Complete Play Console's Data safety, privacy policy, app access, subscription disclosures, and any required permissions declarations. Broad package visibility and all-files access are subject to Google Play policy review; approval is not guaranteed.

## Version 9.0 build
- Version code: 9; version name: 9.0.
- GitHub Actions artifact: `theunkwn-v9-debug-signed-apk` (debug/test build only; not suitable for production Play publishing).
- Production Play upload should use a signed Android App Bundle (AAB) with a private release signing configuration. No release keystore or credentials are included in this project.


## Version 10.0 — internal testing and Play release preparation

### Subscription entitlement behavior
- Free users retain local device scanning, app privacy auditing, watchdog features, and security reports.
- Integrated AI web research is gated behind a verified Premium subscription. The app does not unlock Premium from a local preference alone; the purchase token is checked against Google Play by the backend.
- Pending purchases do not unlock Premium. A successful purchase is verified and acknowledged by the backend. If verification is unavailable, Premium stays locked until verification succeeds.
- Product IDs remain `theunkwn_premium_monthly` and `theunkwn_premium_yearly`. Create each as a subscription in Play Console and activate a base plan with the intended monthly/yearly billing period. Product IDs are case-sensitive and cannot be changed after creation.
- The app reads localized product information from Google Play at purchase time. Set prices, regions, trials and offers in Play Console; do not hardcode prices in the app.

### Release signing / Android App Bundle
- The workflow always creates a debug APK for device development.
- To create a Play-uploadable signed AAB, first create an upload keystore locally and keep a secure offline backup. Never commit the keystore or passwords to GitHub or include them in this ZIP.
- Example (run on a computer with JDK installed):
  `keytool -genkeypair -v -keystore theunkwn-upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias theunkwn-upload`
- Add these GitHub repository **Actions secrets**: `ANDROID_KEYSTORE_BASE64` (base64 of the JKS file), `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, and `ANDROID_KEY_PASSWORD`. On Linux/macOS, produce the one-line base64 value with `base64 -w 0 theunkwn-upload.jks` (macOS: `base64 theunkwn-upload.jks | tr -d '\n'`). On Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes('theunkwn-upload.jks'))`.
- Add the repository **Actions variable** `BUILD_RELEASE` with value `true`. Run Actions → Build TheUnkwn 10.0 → Run workflow. The `theunkwn-v10-release-aab` artifact is the signed AAB for Play Console's internal test track. The debug APK artifact is not the production Play upload artifact.
- Enroll in Play App Signing when Play Console offers it. The local keystore is your upload key; Google Play manages the app signing key. Keep the upload key and passwords backed up securely. If you lose the upload key, follow Google's reset process.

### Required backend configuration
- Deploy `ai-backend/` to a private/controlled HTTPS service. Set `GOOGLE_PLAY_PACKAGE_NAME=com.theunkwn.security` and `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` as server-side secrets. Grant the service account the minimum Play Console permissions required to view subscription orders and acknowledge purchases, and enable the Google Play Android Developer API in its Google Cloud project.
- Set `OPENAI_API_KEY` and/or `GEMINI_API_KEY` only if you want the shared-backend AI option. The personal OpenAI-key pairing mode sends the user's key directly from the phone to OpenAI and does not use the backend for AI inference.
- Paste the backend HTTPS base URL into the app's AI Provider & API Pairing screen. This backend URL is also required for server-side subscription verification, even if the user chooses direct OpenAI key mode.
- **Important pre-public-launch security requirement:** the included backend has basic per-IP rate limiting but does not yet implement user authentication or Android app attestation. Do not expose its AI endpoint as an unrestricted public proxy. Before public launch, add and test Firebase App Check plus user authentication or an equivalent API-gateway control, enforce per-user/provider spending limits, and monitor abuse. Keep provider keys and Play service-account JSON in the hosting provider's secret manager only.
- The Play verification endpoint checks the package configured on the server and the allowed subscription product IDs. Do not rely on a client-supplied `active` flag. Backend availability is required to activate or refresh entitlement. Client-side feature gating is not DRM: a rooted or repackaged app can tamper with local state. For stronger paid-feature enforcement, route premium AI requests through an authenticated backend that independently checks the Play entitlement; the optional direct-to-OpenAI personal-key mode is convenience-oriented and cannot prevent a modified client from bypassing local UI checks.

### Internal test purchase — exact steps
1. In Play Console, open **Test and release → Testing → Internal testing** and create an internal test track.
2. Under **Testers**, create an email list and add the Google account email used on your Android phone. Save the list and copy the opt-in link.
3. Separately open **Settings → License testing** (the exact navigation label may vary in Play Console), add the same Google account as a license tester, and save. Being on the internal-test list alone does not necessarily make purchases test transactions.
4. Under **Monetize with Play → Products → Subscriptions**, create `theunkwn_premium_monthly` with an active monthly base plan and `theunkwn_premium_yearly` with an active yearly base plan. Set regional prices and activate the plans. Publish/save the subscription products so they are available to test.
5. Create and publish an internal test release containing the signed `app-release.aab` artifact. The application ID must remain `com.theunkwn.security`. Wait for Play to process the release.
6. On the phone, sign in to Google Play with the license-tester account. Open the opt-in link on that same device, accept the test, then install TheUnkwn from the Play Store page shown by the link. Do not test billing from an unrelated sideloaded build unless it is a matching package and the account is correctly licensed.
7. Open TheUnkwn → Premium Subscriptions → choose Monthly or Yearly. Google Play's purchase sheet should identify the transaction as a test purchase and offer test payment methods. Choose **Test card, always approves** for a successful purchase. No normal customer charge should be made for a properly configured license tester. Choose **Test card, always declines** to verify the failure path.
8. Confirm that the backend returns a verified active entitlement and that Premium AI research unlocks only after verification. Then use **Restore purchases**, close/reopen the app, and confirm the entitlement refreshes.
9. Test cancellation, expiry/renewal, pending payment, declined renewal, grace period/account hold where available, and reinstall/restore. Use Play Billing Lab with the same license tester account to accelerate subscription lifecycle tests. Test subscriptions can renew on an accelerated schedule, so do not interpret their test duration as the real monthly/yearly duration.
10. Check Play Console order/subscription status and backend logs. Do not log purchase tokens or API keys. If verification fails, keep Premium locked and check backend service-account access, product IDs, package name, and server URL.

### Internal test troubleshooting
- **Product not found:** check exact product ID, active base plan, country availability, and that the subscription product was saved/published.
- **Billing unavailable / item unavailable:** install from the Play opt-in link using the same Google account, wait for the track to propagate, and confirm the package name matches Play Console.
- **A real payment method appears:** confirm the purchasing Google account is on the Play Console License testing list, not merely the internal testers list. Do not proceed with a real payment unless you intend to pay.
- **Purchase succeeds but Premium stays locked:** verify the HTTPS backend URL, Play service account JSON, Android Publisher API enablement, Play Console service-account permissions, product IDs, and server logs. Never manually flip a local preference to unlock Premium.
- **Purchase acknowledgement:** Google Play test purchases that are not acknowledged can be automatically refunded after a short test window (Google documents 3 minutes for license-tester purchases). The backend attempts to acknowledge verified purchases; confirm that this path succeeds in logs.

### Version 10.0 build status
- Version code: 10; version name: 10.0.
- GitHub Actions workflow: `Build TheUnkwn 10.0`.
- Debug artifact: `theunkwn-v10-debug-apk`.
- Signed Play App Bundle artifact (only when repository variable `BUILD_RELEASE=true` and all four keystore secrets are configured): `theunkwn-v10-release-aab`.
- This project archive has not been compiled or device-tested in this environment. A successful GitHub Actions build and a completed Play internal test are still required before launch.

## Branded artwork and bundled build tools

- `app/src/main/res/drawable-nodpi/brand_backdrop.webp` is a lossless WebP copy of the supplied original front-page wallpaper; decoded pixels are identical to the supplied PNG.
- `app/src/main/res/drawable-nodpi/secondary_backdrop.png` is the supplied second artwork, cleaned to a single PocketRealmStudios corner watermark. The title and watermark overlays use the bundled hacker-style font at 60% opacity.
- `app/src/main/res/font/theunkwn_hacker.ttf` is the bundled display font used by the app title and branding.
- The Gradle 8.9 binary distribution is downloaded on first build by the Gradle Wrapper from the official Gradle service. Its SHA-256 is pinned in `gradle/wrapper/gradle-wrapper.properties` using `distributionSha256Sum`.

Build with the bundled distribution from the project root:

- Linux/macOS: `./build-with-bundled-gradle.sh --no-daemon assembleDebug`
- Windows PowerShell: `./build-with-bundled-gradle.ps1 --no-daemon assembleDebug`

The GitHub Actions workflow in `.github/workflows/android.yml` checks required Android/Gradle files, verifies the Gradle distribution and wrapper JAR, installs JDK 17 and Android SDK 35, and builds the debug APK. A signed Play App Bundle is optional and requires the documented GitHub Actions secrets and `BUILD_RELEASE=true` repository variable.

## v12 changes
Ninjuku learns a local entropy baseline from unflagged scanned samples. This is experimental unsupervised anomaly detection, not a trained malware classifier; unflagged samples are not verified clean and baseline poisoning is possible. Reset from Ninjuku page. No automatic isolation from model output. Existing signature/heuristic engine remains. No live malware feed. Premium uses existing monthly/yearly product IDs and existing HTTPS verification backend; configure Play Console and deploy backend before selling. AdMob sample banner only, with UMP consent; no revenue, native/rewarded ads not implemented. Custom PocketRealm Cipher display font covers letters, space, slash and ampersand; not a complete text font or registered trademark. Existing font retained for workflow compatibility. Build and device tests pending.
