import express from 'express';
import { google } from 'googleapis';

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '16kb' }));

const PORT = Number(process.env.PORT || 8080);
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-5-mini';
const GEMINI_MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const PLAY_PACKAGE_NAME = process.env.GOOGLE_PLAY_PACKAGE_NAME || 'com.theunkwn.security';
const PLAY_SERVICE_ACCOUNT_JSON = process.env.GOOGLE_PLAY_SERVICE_ACCOUNT_JSON;
const WINDOW_MS = 60_000;
const MAX_REQUESTS_PER_WINDOW = Number(process.env.MAX_REQUESTS_PER_MINUTE || 12);
const rateBuckets = new Map();

function rateLimit(req, res, next) {
  const now = Date.now();
  const key = req.ip || req.socket.remoteAddress || 'unknown';
  const current = rateBuckets.get(key) || { start: now, count: 0 };
  if (now - current.start >= WINDOW_MS) { current.start = now; current.count = 0; }
  current.count += 1;
  rateBuckets.set(key, current);
  if (current.count > MAX_REQUESTS_PER_WINDOW) {
    return res.status(429).json({ error: 'Rate limit reached. Wait one minute and try again.' });
  }
  next();
}

app.get('/health', (_req, res) => res.json({ ok: true, service: 'theunkwn-ai', providers: {
  openai: Boolean(OPENAI_API_KEY), gemini: Boolean(GEMINI_API_KEY)
} }));

app.post('/api/play/verify', rateLimit, async (req, res) => {
  const productId = String(req.body?.productId || '');
  const purchaseToken = String(req.body?.purchaseToken || '');
  const allowedProducts = new Set(['theunkwn_premium_monthly', 'theunkwn_premium_yearly']);
  if (!allowedProducts.has(productId) || !purchaseToken || purchaseToken.length > 4096) {
    return res.status(400).json({ error: 'Invalid subscription product or purchase token.' });
  }
  if (!PLAY_SERVICE_ACCOUNT_JSON) return res.status(503).json({ error: 'Google Play verification is not configured on this server.' });
  try {
    const credentials = JSON.parse(PLAY_SERVICE_ACCOUNT_JSON);
    const auth = new google.auth.GoogleAuth({ credentials, scopes: ['https://www.googleapis.com/auth/androidpublisher'] });
    const publisher = google.androidpublisher({ version: 'v3', auth });
    const result = await publisher.purchases.subscriptionsv2.get({ packageName: PLAY_PACKAGE_NAME, token: purchaseToken });
    const subscription = result.data;
    const line = (subscription.lineItems || []).find(item => item.productId === productId);
    const expiry = line?.expiryTime ? Date.parse(line.expiryTime) : 0;
    const state = subscription.subscriptionState || '';
    const stateAllowsAccess = ['SUBSCRIPTION_STATE_ACTIVE', 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD', 'SUBSCRIPTION_STATE_CANCELED'].includes(state);
    const active = Boolean(line && stateAllowsAccess && expiry > Date.now());
    if (active && state !== 'SUBSCRIPTION_STATE_PENDING') {
      try {
        await publisher.purchases.subscriptions.acknowledge({ packageName: PLAY_PACKAGE_NAME, subscriptionId: productId, token: purchaseToken, requestBody: {} });
      } catch (ackError) {
        // An already-acknowledged purchase may return an error; entitlement still depends on Play's verified state.
      }
    }
    res.json({ active, productId: line?.productId || null, expiryTime: line?.expiryTime || null, subscriptionState: state });
  } catch (err) {
    console.error(`Google Play verification failed: ${String(err?.message || 'unknown').slice(0, 240)}`);
    res.status(502).json({ error: 'Google Play could not verify this subscription token.' });
  }
});

app.post('/api/chat', rateLimit, async (req, res) => {
  const provider = String(req.body?.provider || '').toLowerCase();
  const message = String(req.body?.message || '').trim();
  if (!['openai', 'gemini'].includes(provider)) return res.status(400).json({ error: 'Provider must be openai or gemini.' });
  if (!message || message.length > 6000) return res.status(400).json({ error: 'Enter a question of 1–6000 characters.' });
  try {
    const result = provider === 'openai'
      ? await askOpenAI(message)
      : await askGemini(message);
    res.json(result);
  } catch (err) {
    // Do not log prompts, provider responses, or secret-bearing request headers.
    console.error(`AI provider request failed (${provider}): ${String(err?.message || 'unknown').slice(0, 300)}`);
    res.status(502).json({ error: 'The selected AI provider could not complete the request. Check server API-key configuration and provider billing/quota.' });
  }
});

async function askOpenAI(message) {
  if (!OPENAI_API_KEY) throw new Error('OPENAI_API_KEY is not configured');
  const response = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: { Authorization: `Bearer ${OPENAI_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      tools: [{ type: 'web_search', search_context_size: 'medium' }],
      tool_choice: 'auto',
      instructions: 'You are TheUnkwn security research assistant. Search the web when current or verifiable information is useful. Distinguish confirmed facts from hypotheses, prioritize vendor advisories and CVE/NVD/CISA sources, explain uncertainty, and never claim a file is malware without evidence. Cite sources in your answer.',
      input: message
    }),
    signal: AbortSignal.timeout(110_000)
  });
  const data = await response.json();
  if (!response.ok) throw new Error(`OpenAI HTTP ${response.status}: ${data?.error?.message || 'request rejected'}`);
  const answer = data.output_text || extractOpenAIText(data.output) || 'No text answer returned.';
  const citations = [];
  const seen = new Set();
  for (const item of (data.output || [])) {
    for (const part of (item.content || [])) {
      for (const annotation of (part.annotations || [])) {
        const url = annotation.url;
        if (url && !seen.has(url)) {
          seen.add(url);
          citations.push({ title: annotation.title || url, url });
        }
      }
    }
  }
  return { answer, citations, provider: 'openai', model: OPENAI_MODEL };
}

function extractOpenAIText(output = []) {
  return output.flatMap(item => item.content || [])
    .filter(part => part.type === 'output_text' || part.type === 'text')
    .map(part => part.text || '').join('\n');
}

async function askGemini(message) {
  if (!GEMINI_API_KEY) throw new Error('GEMINI_API_KEY is not configured');
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(GEMINI_MODEL)}:generateContent?key=${encodeURIComponent(GEMINI_API_KEY)}`;
  const response = await fetch(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ role: 'user', parts: [{ text: `You are TheUnkwn security research assistant. Use Google Search grounding for current or verifiable information. Prioritize vendor advisories and CVE/NVD/CISA sources, distinguish facts from hypotheses, explain uncertainty, and never claim a file is malware without evidence. Answer clearly: ${message}` }] }],
      tools: [{ googleSearch: {} }],
      generationConfig: { temperature: 0.7, maxOutputTokens: 4096 }
    }),
    signal: AbortSignal.timeout(110_000)
  });
  const data = await response.json();
  if (!response.ok) throw new Error(`Gemini HTTP ${response.status}: ${data?.error?.message || 'request rejected'}`);
  const answer = (data.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('\n') || 'No text answer returned.';
  const citations = [];
  const seen = new Set();
  for (const chunk of (data.candidates?.[0]?.groundingMetadata?.groundingChunks || [])) {
    const web = chunk.web;
    if (web?.uri && !seen.has(web.uri)) {
      seen.add(web.uri);
      citations.push({ title: web.title || web.uri, url: web.uri });
    }
  }
  return { answer, citations, provider: 'gemini', model: GEMINI_MODEL };
}

app.listen(PORT, '0.0.0.0', () => console.log(`TheUnkwn AI backend listening on ${PORT}`));
