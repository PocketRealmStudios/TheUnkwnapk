$ErrorActionPreference = "Stop"
# Uses the official Gradle Wrapper. Gradle 8.9 is downloaded on first use
# and verified against distributionSha256Sum in gradle-wrapper.properties.
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Wrapper = Join-Path $Root "gradlew.bat"
& $Wrapper @args
exit $LASTEXITCODE
